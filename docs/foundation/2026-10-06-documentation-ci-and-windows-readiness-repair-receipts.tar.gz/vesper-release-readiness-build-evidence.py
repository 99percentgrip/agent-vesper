from pathlib import Path
import hashlib,json,subprocess,tarfile,io,re
root=Path('/tmp');repo=root/'vesper-production-release';dst=repo/'docs/foundation';stem='2026-10-06-documentation-ci-and-windows-readiness-repair'
focused=json.loads((root/'vesper-release-readiness-diagnostic-matrix.json').read_text())
assert focused['conclusion']=='failure' and len(focused['jobs'])==3
job_details=json.loads((root/'vesper-release-readiness-diagnostic-jobs.json').read_text())
for job in job_details['jobs']:
 assert all(step['conclusion']=='success' for step in job['steps'] if step['name'].startswith('Native') and step['conclusion']!='skipped')
 assert [step['name'] for step in job['steps'] if step['conclusion']=='failure']==(['Formatting and whitespace'] if job['name']=='windows-x86_64' else [])
assert all(j['rust_passed']==(35 if j['name']=='windows-x86_64' else 55) for j in focused['jobs'])
files=sorted([p for prefix in ['vesper-release-readiness-','vesper-release-documentation-closeout-'] for p in root.glob(prefix+'*') if p.is_file() and p.suffix in ['.json','.log','.py']])
files += [root/n for n in ['vesper-release-post-main-controller.rs','vesper-release-focused-cargo.rs','vesper-release-windows-sse-native-linkage.json']]
files=list(dict.fromkeys(files));out=root/'vesper-release-readiness-pre-main-sanitized';assert not out.exists()
subprocess.run(['/tmp/rrc-parity-redact-receipt',str(out),*[str(p) for p in files]],check=True,capture_output=True)
original={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files};receipts=[];archive=dst/(stem+'-receipts.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(out.iterdir()):
  b=p.read_bytes()
  if p.suffix=='.json':json.loads(b)
  info=tarfile.TarInfo(p.name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b));receipts.append({'path':p.name,'bytes':len(b),'source_sha256':original[p.name],'sha256':hashlib.sha256(b).hexdigest()})
byname={r['path']:r for r in receipts}
for j in focused['jobs']:
 name=Path(j['log']).name;j['archived_log_sha256']=byname[name]['sha256'];s=(out/name).read_text()
 cases=['descendant_writing_after_leader_exit_is_cleaned','leader_exit_does_not_wait_for_descendant_held_pipe','held_pipe_fixture_allows_slow_startup_before_settlement','writer_fixture_allows_slow_startup_before_settlement']
 if j['name']!='windows-x86_64':cases+=['session_tests::timeout_is_bounded_quarantined_and_never_replayed']
 assert all(re.search(r'test '+re.escape(c)+r' \.\.\. ok',s) for c in cases);j['named_causal_cases']=cases
format_proof=json.loads((root/'vesper-release-readiness-format-native-proof.json').read_text());assert format_proof['conclusion']=='success'
v={'windows_format_follow_up':format_proof,'production_base':'3df2feb69dc120b13d02a143f5df6aba8536d8d1','published_release_source':'7e837db36f4090e566ac1a7461b5b103b8649368','status':'All 145 native functional executions passed. The first Windows job failed only the added diagnostic formatting step due to CRLF checkout; retain that failure. Full corrected exact-main matrix pending before push. No new release authorized or created.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'focused_native':focused,'source_equivalence':json.loads((root/'vesper-release-readiness-diagnostic-source-equivalence.json').read_text()),'receipts':receipts,'limits':['Windows MCP Unix-only suite not executed or counted.','Deliberately cancelled docs-triggered jobs are not passes.','Native controller observes manual source repair; no live-model repair efficacy claim.','Published v0.24.5 and its 111 frozen final receipts are unchanged.']}
(dst/(stem+'-evidence.json')).write_text(json.dumps(v,indent=2)+'\n')
print('Created',len(receipts),'sanitized receipts; 145 native Rust case executions')
