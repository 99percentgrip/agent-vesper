import json,subprocess,pathlib,hashlib,time
root=pathlib.Path('/tmp');repo='99percentgrip/agent-vesper-rrc-public-acceptance';run_id=37423097009;sha='dbd5fafb276c770bf26912165e7f61b2a524c7e4'
def api(p):return json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/{p}']))
for _ in range(120):
 run=api(f'actions/runs/{run_id}')
 if run['status']=='completed':break
 time.sleep(5)
else:raise RuntimeError('Bounded Windows formatting proof did not settle')
jobs=api(f'actions/runs/{run_id}/jobs');assert run['head_sha']==sha and len(jobs['jobs'])==1
(root/'vesper-release-readiness-format-native-run.json').write_text(json.dumps(run,indent=2)+'\n')
(root/'vesper-release-readiness-format-native-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
job=jobs['jobs'][0];p=root/f"vesper-release-readiness-format-native-job-{job['id']}.log";p.write_bytes(subprocess.check_output(['gh','api','--allow-escape-sequences',f"repos/{repo}/actions/jobs/{job['id']}/logs"]))
v={'run_id':run_id,'head_sha':sha,'conclusion':run['conclusion'],'job_id':job['id'],'log':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Windows formatting/whitespace and 10 CI-policy regressions only; zero Rust functional cases rerun.'};(root/'vesper-release-readiness-format-native-proof.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True)
assert run['conclusion']==job['conclusion']=='success'
