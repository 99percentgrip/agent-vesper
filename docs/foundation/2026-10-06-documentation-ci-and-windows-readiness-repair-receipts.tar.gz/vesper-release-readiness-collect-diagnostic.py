import json,subprocess,pathlib,hashlib,time,re
repo='99percentgrip/agent-vesper-rrc-public-acceptance';run_id=37422442222;sha='3228a711c102e87aad5a71855aab7795b3362eef';root=pathlib.Path('/tmp')
def api(p):return json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/{p}']))
for attempt in range(80):
 run=api(f'actions/runs/{run_id}'); jobs=api(f'actions/runs/{run_id}/jobs?per_page=100')
 print([(j['name'],j['status'],j['conclusion']) for j in jobs['jobs']],flush=True)
 if run['status']=='completed':break
 time.sleep(30)
else:raise RuntimeError('Focused matrix did not settle within bounded observation')
assert run['head_sha']==sha and len(jobs['jobs'])==3 and all(j['status']=='completed' for j in jobs['jobs'])
(root/'vesper-release-readiness-diagnostic-run.json').write_text(json.dumps(run,indent=2)+'\n')
(root/'vesper-release-readiness-diagnostic-jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
observations=[]
for job in jobs['jobs']:
 path=root/f"vesper-release-readiness-diagnostic-job-{job['id']}.log"
 path.write_bytes(subprocess.check_output(['gh','api','--allow-escape-sequences',f"repos/{repo}/actions/jobs/{job['id']}/logs"]))
 log=path.read_text(errors='replace')
 results=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)]
 observations.append({'job_id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'log':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'actual_test_results':results,'rust_passed':sum(r['passed'] for r in results)})
result={'repo':repo,'run_id':run_id,'head_sha':sha,'conclusion':run['conclusion'],'jobs':observations}
(root/'vesper-release-readiness-diagnostic-matrix.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
assert run['conclusion']=='success' and all(j['conclusion']=='success' for j in jobs['jobs'])
assert all(o['rust_passed']==(35 if o['name']=='windows-x86_64' else 55) for o in observations),observations
