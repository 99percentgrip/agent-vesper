use vesper_harness::release_recovery::{GhCliEvidenceAdapter, GitHubEvidencePort, ReleaseRecoveryState, RetryKind, start_release, refresh_remote_evidence, compare_with_last_green};
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let repo = "99percentgrip/agent-vesper-rrc-acceptance";
    let adapter = GhCliEvidenceAdapter;
    let mut fingerprints = Vec::new();
    for sha in &args[1..] {
        let gates = adapter.matrix_for_sha(repo, sha).expect("actual GitHub adapter inventory");
        let fixture = gates.into_iter().find(|g| g.name == "rrc-controlled-acceptance").expect("controlled workflow");
        assert!(fixture.matrix_complete());
        assert_eq!(fixture.jobs.len(), 5);
        assert_eq!(fixture.head_sha, *sha);
        let mut record = start_release("controlled-audit", "patch", "main", sha).unwrap();
        record.objective.required_gate_names = vec!["rrc-controlled-acceptance".into()];
        record.state = ReleaseRecoveryState::RemoteGateRunning;
        refresh_remote_evidence(&mut record, repo, &adapter).unwrap();
        if fixture.has_failure() {
            assert_eq!(record.state, ReleaseRecoveryState::ClassifyingFailure);
            assert_eq!(record.failures.len(), 1);
            let failure = &record.failures[0];
            assert!(failure.causal_excerpt.contains("rrc_fixture_assertion_42"));
            assert!(!failure.causal_excerpt.contains("github_pat_RRCACCEPTANCE"));
            assert!(!record.render_status().contains("github_pat_RRCACCEPTANCE"));
            println!("FINGERPRINT sha={sha} hash={} workflow={} job={} step={:?} platform={:?} excerpt={:?}", failure.fingerprint.0, failure.workflow_name, failure.job_name, failure.step_name, failure.platform, failure.causal_excerpt);
            fingerprints.push(failure.fingerprint.clone());
            assert!(!record.retry_admission(RetryKind::FullGate).admitted);
            compare_with_last_green(&mut record, repo, &args[2], false, &adapter).unwrap();
            assert_eq!(record.failures[0].exists_on_last_green, Some(false));
            println!("sha={sha} run={:?} jobs=5 state=ClassifyingFailure causal/policy/redaction/last-green=PASS", fixture.run_id);
        } else {
            assert_eq!(record.state, ReleaseRecoveryState::RemoteGatesGreen);
            println!("sha={sha} run={:?} jobs=5 state=RemoteGatesGreen", fixture.run_id);
        }
    }
    assert!(fingerprints.len() >= 2);
    assert!(fingerprints.windows(2).all(|pair| pair[0] == pair[1]));
    println!("Repeated actual CI causal fingerprints are stable; no GitHub write or ledger write performed.");
}
