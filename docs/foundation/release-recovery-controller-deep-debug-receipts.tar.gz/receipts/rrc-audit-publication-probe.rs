use std::sync::{Arc, atomic::AtomicBool};
use vesper_harness::release_executor::{NativeReleaseExecutor, ReleaseExecutionPort};
fn main() {
 let executor=NativeReleaseExecutor::new(std::path::Path::new("/home/Alex/Projects/agent-vesper"), Arc::new(AtomicBool::new(false))).unwrap();
 let receipt=executor.publication("99percentgrip/agent-vesper", "v0.24.4", "d22113528362706fa1672051dcb9385c82c22d8d").unwrap().expect("existing published release");
 println!("Read-only native verifier: version={} workflow_run={} assets={}; exact annotated tag, stable metadata, server archive digests and downloaded checksum contents PASS",receipt.version,receipt.run_id,receipt.assets.len());
 println!("Existing historical release only; no current producer workflow run, tag or publication performed.");
}
