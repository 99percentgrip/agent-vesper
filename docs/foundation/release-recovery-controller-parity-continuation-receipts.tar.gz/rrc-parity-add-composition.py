from pathlib import Path
p=Path('crates/vesper-harness/src/release_executor.rs');s=p.read_text()
a=s.index('    let failure = record',s.index('fn run_bounded_repair_agent('));s=s[:a]+'''    let root = default_release_root().ok_or_else(|| {
        RrcError::Invalid("no user-owned release state root is available".into())
    })?;
    run_bounded_repair_agent_with_verification(workspace, record, ledger, factory, cancelled,
        RepairVerification { root: &root, verify: &|executor| {
            for gate in production_local_gates() { executor.run_local_gate(&gate)?; }
            Ok(())
        } })
}

// Internal composition seam: production always supplies the full native gate set.
struct RepairVerification<'a> {
    root: &'a Path,
    verify: &'a dyn Fn(&NativeReleaseExecutor) -> Result<(), RrcError>,
}

fn run_bounded_repair_agent_with_verification(
    workspace: &Path,
    record: &mut ReleaseRecoveryRecord,
    ledger: &ReleaseLedger,
    factory: &crate::WorkerFactory,
    cancelled: Arc<AtomicBool>,
    verification: RepairVerification<'_>,
) -> Result<(), RrcError> {
'''+s[a:]
s=s.replace('''    let repair_root = default_release_root()
        .ok_or_else(|| RrcError::Invalid("no user-owned release state root is available".into()))?
        .join("worktrees")''','''    let repair_root = verification.root.join("worktrees")''')
s=s.replace('''        for gate in production_local_gates() {
            repair_executor.run_local_gate(&gate)?;
        }''','''        (verification.verify)(&repair_executor)?;''',1)
# Extract the existing test's factory construction into a shared test fixture.
a=s.index('    #[test]\n    fn repair_factory_executes_real_tools_for_two_provider_fixtures()');b=s.index('\n    #[test]\n    fn version_bump_updates_only',a);old=s[a:b]
start=old.index('        use vesper_domain::');end=old.index('        for label in [');fixture=old[start:end]
session_a=old.index('            let session = vesper_testkit');session_b=old.index('            let (outcome, history)',session_a)
build=old[session_a:session_b]
helper='''    fn repair_test_factory(label: &str, repaired: &str) -> (crate::WorkerFactory, vesper_testkit::FakeProviderSession, tokio::runtime::Runtime) {
'''+fixture+build+'''        (factory, session, runtime)
    }

'''
remaining=old[:start]+old[end:session_a]+'''            let (factory, session, runtime) = repair_test_factory(label, &repaired);
'''+old[session_b:]
s=s[:a]+helper+remaining+s[b:]
# New complete production-composition fixture; only the fixture's post-proof gate port is substituted.
pos=s.index('    #[test]\n    fn version_bump_updates_only')
new='''    #[test]
    fn isolated_agent_repair_verifies_and_promotes_one_patch_for_two_provider_fixtures() {
        for label in ["fixture.release-a", "fixture.release-b"] {
            let temp = tempfile::tempdir().unwrap();
            let workspace = temp.path().join("workspace");
            fs::create_dir_all(workspace.join("src")).unwrap();
            fs::write(workspace.join("Cargo.toml"), "[package]\\nname=\\"repair-composition\\"\\nversion=\\"0.1.0\\"\\nedition=\\"2024\\"\\n").unwrap();
            fs::write(workspace.join(".gitattributes"), "* text eol=lf\\n").unwrap();
            fs::write(workspace.join(".gitignore"), "/target/\\n").unwrap();
            let broken = "pub fn answer() -> u32 { 0 }\\n#[test] fn exact_regression() { assert_eq!(answer(), 42); }\\n";
            let repaired = broken.replace("{ 0 }", "{ 42 }");
            fs::write(workspace.join("src/lib.rs"), broken).unwrap();
            let native = NativeReleaseExecutor::new(&workspace, Arc::new(AtomicBool::new(false))).unwrap();
            native.checked("git", &["init","-b","main"]).unwrap();
            native.checked("git", &["config","user.name","fixture"]).unwrap();
            native.checked("git", &["config","user.email","fixture@example.invalid"]).unwrap();
            assert!(!native.command("cargo", &["test","exact_regression","--offline"]).unwrap().status.success());
            native.checked("git", &["add","--all"]).unwrap();
            native.checked("git", &["commit","-m","fixture red regression"]).unwrap();
            let base = native.checked("git", &["rev-parse","HEAD"]).unwrap().trim().to_owned();
            let mut record = crate::release_recovery::start_release("composition", "patch", "main", &base).unwrap();
            record.state = ReleaseRecoveryState::ClassifyingFailure;
            record.mutation.candidate_committed = true;
            record.mutation.candidate_pushed = true;
            record.mutation.candidate_push_ref = Some(format!("origin/main@{base}"));
            record.required_gates = GreenGithub.matrix_for_sha("fixture/repo", &base).unwrap();
            record.required_gates[0].jobs[0].state = crate::release_recovery::JobState::Failure;
            record.required_gates[0].run_state = Some(crate::release_recovery::JobState::Failure);
            record.failures.push(crate::release_recovery::FailureRecord {
                workflow_id:1, run_id:1, attempt:1, job_id:1, workflow_name:record.required_gates[0].name.clone(),
                job_name:record.required_gates[0].jobs[0].job_name.clone(), platform:Some(std::env::consts::OS.into()),
                step_name:Some("cargo test exact_regression".into()), fingerprint:crate::release_recovery::FailureFingerprint("fixture-regression".into()),
                class:crate::release_recovery::ReleaseFailureClass::TestRegression,
                confidence:crate::release_recovery::EvidenceConfidence::Proven,
                causal_excerpt:"thread 'exact_regression' panicked at src/lib.rs:2: assertion failed".into(),
                source_commit:base.clone(), observed_at:Utc::now(), other_platforms_passed:true,
                exists_on_last_green:Some(false), related_source_touched:Some(true),
            });
            let ledger = ReleaseLedger::open(temp.path().join("state"), "composition").unwrap();
            ledger.save(&record).unwrap();
            let (factory, session, _runtime) = repair_test_factory(label, &repaired);
            let gates_observed = std::sync::atomic::AtomicUsize::new(0);
            let verify_fixture_gates = |executor: &NativeReleaseExecutor| {
                gates_observed.fetch_add(1, Ordering::SeqCst);
                assert_ne!(executor.workspace, workspace, "verification must use the isolated worktree");
                executor.checked("cargo", &["test","--offline"])?;
                Ok(())
            };
            run_bounded_repair_agent_with_verification(&workspace, &mut record, &ledger, &factory,
                Arc::new(AtomicBool::new(false)), RepairVerification {
                    root: &temp.path().join("state"), verify: &verify_fixture_gates,
                }).unwrap();
            assert_eq!(gates_observed.load(Ordering::SeqCst),1);
            assert_eq!(session.requests().len(),3);
            assert_eq!(record.state,ReleaseRecoveryState::RetryAdmissible);
            assert_eq!(record.repair_attempts.len(),1);
            let receipt = &record.repair_attempts[0];
            assert_eq!(receipt.source_commit_before,base);
            assert_ne!(receipt.source_commit_after.as_deref(),Some(base.as_str()));
            assert_eq!(receipt.focused_status,crate::release_recovery::FocusedProofStatus::Passed);
            assert!(!receipt.hypothesis.is_empty());
            assert_eq!(fs::read_to_string(workspace.join("src/lib.rs")).unwrap(),repaired);
            assert!(native.checked("git", &["status","--porcelain"]).unwrap().is_empty());
            assert_eq!(native.checked("git", &["diff","--name-only",&base,"HEAD"]).unwrap().trim(),"src/lib.rs");
            assert!(!record.mutation.candidate_pushed);
            assert_eq!(record.retry_budget.full_gate_used,0,"promotion is not a remote retry");
            assert!(record.metrics.model_active_millis>0);
            assert_eq!(ledger.load().unwrap().unwrap(),record);
        }
    }

'''
s=s[:pos]+new+s[pos:];p.write_text(s)
