import concurrent.futures,hashlib,io,json,lzma,pathlib,tarfile,time,urllib.request
rows=json.load(open('/tmp/rrc-parity-headless-package-proof.json'))
def proof(row):
 started=time.monotonic();url='https://deb.debian.org/debian-security/'+row['Filename'];parts=[];digest=hashlib.sha256();size=0
 with urllib.request.urlopen(url,timeout=30) as response:
  while block:=response.read(1024*1024):
   size+=len(block);assert size<256*1024*1024 and time.monotonic()-started<90
   digest.update(block);parts.append(block)
 assert digest.hexdigest()==row['SHA256'], 'package digest mismatch'
 archive=b''.join(parts);assert archive[:8]==b'!<arch>\n';offset=8;control=None
 while offset<len(archive):
  header=archive[offset:offset+60];assert header[58:60]==b'`\n';length=int(header[48:58]);name=header[:16].decode().strip().rstrip('/');offset+=60
  if name.startswith('control.tar'):
   with tarfile.open(fileobj=io.BytesIO(archive[offset:offset+length]),mode='r:*') as tar:
    member=next(x for x in tar.getmembers() if x.name in ('control','./control'));control=tar.extractfile(member).read().decode()
  offset+=length+(length%2)
 assert control is not None
 fields=dict(line.split(': ',1) for line in control.splitlines() if ': ' in line and not line.startswith(' '))
 for field in ['Package','Version','Architecture']:assert fields[field]==row[field],(field,fields.get(field),row[field])
 return {**row,'download_url':url,'download_sha256':digest.hexdigest(),'download_bytes':size,'control_identity_verified':True,'elapsed_seconds':round(time.monotonic()-started,3)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(proof,rows))
pathlib.Path('/tmp/rrc-parity-headless-download-proof.json').write_text(json.dumps(results,indent=2)+'\n')
for row in results:print('PASS: downloaded',row['Architecture'],row['Version'],row['download_bytes'],'bytes; verified official SHA256 and .deb control identity; no installation')
