use std::sync::LazyLock;
use regex::Regex;
use std::path::Path;
fn main() {
 let args: Vec<String> = std::env::args().collect();
 let root=Path::new(&args[1]); std::fs::create_dir_all(root).unwrap();
 for path in &args[2..] {
  let path=Path::new(path);let bytes=std::fs::read(path).unwrap();
  let text=String::from_utf8_lossy(&bytes);
  let redacted=redact_secret_text(&text);
  std::fs::write(root.join(path.file_name().unwrap()),redacted).unwrap();
 }
}

fn redact_secret_text(input: &str) -> String {
    static ESCAPES: LazyLock<Regex> = LazyLock::new(|| {
        Regex::new(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)")
            .expect("static terminal escape regex")
    });
    let mut text = ESCAPES
        .replace_all(input, "")
        .chars()
        .filter(|ch| !ch.is_control() || matches!(ch, '\n' | '\r' | '\t'))
        .collect::<String>();
    static PATTERNS: LazyLock<Vec<Regex>> = LazyLock::new(|| {
        [
        r"(?i)(authorization\s*:\s*(?:bearer|token|basic)\s+)[^\s]+",
        r#"(?i)("(?:authorization|github_token|gh_token|api[_-]?key|access[_-]?token|client[_-]?secret)"\s*:\s*")[^"]*"#,
        r"\b(?:sk|xai)-[A-Za-z0-9_-]{16,}\b",
        r"(?i)((?:github_token|gh_token|api[_-]?key|access[_-]?token|client[_-]?secret)\s*[=:]\s*)[^\s]+",
        r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b",
        r"\bgithub_pat_[A-Za-z0-9_]{20,}\b",
        r"(?i)(https?://)[^/\s@]+@",
        r"(?i)([?&](?:token|access_token|api_key|key|signature|sig|x-amz-signature)=)[^&\s]+",
    ].into_iter().map(|pattern| Regex::new(pattern).expect("static credential regex")).collect()
    });
    for regex in PATTERNS.iter() {
        text = regex.replace_all(&text, "$1[REDACTED]").into_owned();
    }
    text
}
