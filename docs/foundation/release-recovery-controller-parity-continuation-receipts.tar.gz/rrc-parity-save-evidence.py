import datetime,hashlib,json,pathlib,subprocess,tarfile,tempfile
root=pathlib.Path('/home/Alex/Projects/agent-vesper');foundation=root/'docs/foundation';m=json.load(open('/tmp/rrc-parity-public-bootstrap.json'));clone=pathlib.Path(m['candidate_dir'])
files=[]
for name in m['scoped_paths']:
 if name.endswith(('parity-continuation-source.json','parity-continuation-receipts.tar.gz')): continue
 before=subprocess.check_output(['git','show',m['candidate_sha']+':'+name],cwd=clone);current=(root/name).read_bytes();same=before==current
 assert same or name.startswith('docs/'), name
 files.append({'path':name,'candidate_sha256':hashlib.sha256(before).hexdigest(),'delivery_sha256':hashlib.sha256(current).hexdigest(),'matches_candidate':same})
paths=sorted(p for p in pathlib.Path('/tmp').glob('rrc-parity*') if p.is_file() and p.suffix in ('.log','.json','.rs','.py'))
with tempfile.TemporaryDirectory(prefix='rrc-parity-receipts-') as folder:
 dest=pathlib.Path(folder)
 subprocess.run(['/tmp/rrc-parity-redact-receipt',str(dest),*[str(p) for p in paths]],check=True)
 receipts=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(dest.iterdir())]
 (dest/'receipt-index.json').write_text(json.dumps({'sanitizer':'exact current production RRC redact_secret_text copied to an evidence-only tool; full receipts without public excerpt cap','receipts':receipts},indent=2)+'\n')
 archive=foundation/'release-recovery-controller-parity-continuation-receipts.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  for p in sorted(dest.iterdir()):tar.add(p,arcname=p.name)
manifest={
 'status':'complete_binding_prd_sections_1_through_36',
 'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'primary_head_unchanged':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'candidate_repository':m['repository'],'candidate_sha':m['candidate_sha'],
 'scope':'runtime, tests and workflows match this frozen public candidate; later delivery documentation is explicit; this manifest and its archive are excluded from their own file inventory to avoid cyclic hashes',
 'files':files,
 'delivery_requirement_trace':{'path':'docs/foundation/release-recovery-controller-parity-continuation-requirements.json','sha256':hashlib.sha256((foundation/'release-recovery-controller-parity-continuation-requirements.json').read_bytes()).hexdigest()},
 'current_native_direct_cases':json.load(open('/tmp/rrc-parity-startup-native-log-checks.json')),
 'current_controlled_settled':json.load(open('/tmp/rrc-parity-startup-controlled-settled.json')),
 'current_main_settled':json.load(open('/tmp/rrc-parity-startup-main-settled.json')),
 'current_main_log_index':json.load(open('/tmp/rrc-parity-startup-main-complete-log-index.json')),
 'current_producing_acceptance':json.load(open('/tmp/rrc-parity-startup-producing-acceptance.json')),
 'current_producing_checksums':json.load(open('/tmp/rrc-parity-startup-producing-checksums.json')),
 'current_publication_settled':json.load(open('/tmp/rrc-parity-startup-publication-settled.json')),
 'current_publication_log_index':json.load(open('/tmp/rrc-parity-startup-publication-log-index.json')),
 'current_producing_ledger_sha256':hashlib.sha256(pathlib.Path('/tmp/rrc-parity-startup-producing-ledger.json').read_bytes()).hexdigest(),
 'local_verification':{'release_filter_cases':83,'dedicated_rrc_cases':82,'other_filter_case':'dependency_setup::tests::linux_distribution_selection_never_executes_os_release_text','exact_acceptance_cases':69,'auth_ui_cases':12,'command_settlement_cases':11,'isolated_acp_repetitions':10,'msrv':'1.88.0','clippy':'passed','native_hosts':'passed','complete_candidate_verify':'passed; observed command exit 0 in isolated final-source worktree; full workspace/default docs/stage checks plus 69 exact cases in 31345 ms'},
 'current_native_and_producing_acceptance':'public current source bd24bb48765d73c704fb81945ca87e33d093e121: five-target native run 37337247051 passed with direct logs and current controlled probes passed; all four current-source main-push prerequisites passed all eleven jobs; actual native annotated tag and producing workflow 37346108219 passed; all 16 assets verified; native closeout Complete',
 'prepared_executor_correction':json.load(open('/tmp/rrc-parity-directive-prepared-source.json')),
 'current_health_policy_correction':json.load(open('/tmp/rrc-parity-health-routing-prepared-source.json')),
 'current_local_checks':json.load(open('/tmp/'+m['local_verification_receipt'])),
 'current_startup_fixture_correction':json.load(open('/tmp/rrc-parity-startup-prepared-source.json')),
 'previous_hosted_native_matrix':json.load(open('/tmp/rrc-parity-hosted-native-settled.json')),
 'current_repair_authority_correction':json.load(open('/tmp/rrc-parity-repair-authority-prepared-source.json')),
 'prepared_repair_cap_correction':json.load(open('/tmp/rrc-parity-repair-cap-prepared-source.json')),
 'prepared_hosted_selection_checks':json.load(open('/tmp/rrc-parity-hosted-selection-local-verification.json')),
 'prepared_hosted_selection_source':json.load(open('/tmp/rrc-parity-hosted-selection-prepared-source.json')),
 'previous_source_main_matrix':json.load(open('/tmp/rrc-parity-authority-main-settled.json')),
 'current_public_controlled_runs':m.get('current_public_controlled_runs',{}),
 'prepared_executor_local_verification':json.load(open('/tmp/rrc-parity-directive-local-verification.json')),
 'previous_public_prerequisites':{'sha':'35026933eff7720c98c6cc2c5d39732e325a9e6a','all_four_workflows_and_all_jobs':'passed','runs':{'canonical':37305251282,'msrv':37305251328,'foundation':37305251429,'web_driver':37305251272}},
 'blocked_focused_attempt':{'sha':'c802e93ea7ce53f97f84fdc39ac15287170a049c','run_id':37300015141,'conclusion':'failure','native_bodies_executed':0,'cause':'owned job annotations: account payments failed or spending limit needs increasing','current_code_read_only_probe':'passed for core classification/directive only; later direct/continuous executor integration gap reproduced and corrected in prepared source'},
 'current_public_focused_run':m['current_public_focused_run'],
 'previous_owner_native_run':{'sha':'be1f945f654499f5cf52806fd23bd8dbce6884fa','run_id':37311288734,'all_five_targets':'passed','release_filter_cases':79},
 'previous_public_focused_run':{'sha':'35026933eff7720c98c6cc2c5d39732e325a9e6a','run_id':37303833246,'all_five_targets':'passed','cases':78},
 'previous_public_controlled_runs':{'sha':'35026933eff7720c98c6cc2c5d39732e325a9e6a','failed_plus_running_then_settled_red':37304066998,'same_fingerprint_red':37304250214,'green':37304525331},
 'public_snapshot_scope':'fresh history; minimal public audit documents and test README; private diagnostic archives retained only in primary workspace',
 'previous_native_focused':{'sha':'2ca3dcbd28a1d98ac7fbf055b1eab858937ae494','run_id':37290680196,'native_rrc_cases':73,'release_filter_cases':74,'all_five_targets':'passed; historical source only'},
 'previous_production_prerequisites':{'sha':'2ca3dcbd28a1d98ac7fbf055b1eab858937ae494','canonical':{'run_id':37292033400,'conclusion':'failure','cause':'LLD signal 7; disk capacity remains hypothesis'},'msrv':{'run_id':37292033297,'conclusion':'cancelled','cause':'30-minute job timeout during exact acceptance'},'foundation':{'run_id':37292033237,'conclusion':'success','all_five_targets':'passed'},'web_driver':{'run_id':37292033235,'conclusion':'success','all_three_jobs':'passed'}},
 'previous_controlled_runs':{'sha':'2ca3dcbd28a1d98ac7fbf055b1eab858937ae494','failed_plus_running_then_settled_red':37290746838,'same_fingerprint_red':37290935256,'green':37291227777},
 'receipt_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'receipt_count':len(receipts),
 'unexecuted':['live model repair effectiveness','real external outage','Alex interactive browser/account completion','production repository publication','local installation replacement'],
 'binding_prd_pending':[]
}
(foundation/'release-recovery-controller-parity-continuation-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Preserved',len(receipts),'sanitized receipts; archive',archive.stat().st_size,'bytes; all runtime/fixture/workflow files match candidate')
