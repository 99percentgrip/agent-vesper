import json,os,pathlib,subprocess,time
r=pathlib.Path('/tmp/rrc-public-directive-worktree')
assert 'startup_bound = Duration::from_secs(15)' in (r/'crates/vesper-agent/tests/command_settlement.rs').read_text()
checks=json.load(open('/tmp/rrc-parity-hosted-selection-local-verification.json'))['checks']
checks.insert(0,{'check':'command-settlement','command':['cargo','test','--locked','-p','vesper-agent','--test','command_settlement','--','--test-threads=1','--nocapture']})
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/home/Alex/Projects/agent-vesper/target/rrc-directive-proof',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='line-tables-only',CARGO_PROFILE_TEST_DEBUG='line-tables-only')
results=[]
for check in checks:
 started=time.time();name=check['check'];print('START',name,flush=True)
 with open('/tmp/rrc-parity-startup-'+name+'.log','w') as f:
  proc=subprocess.run(check['command'],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 results.append({'check':name,'command':check['command'],'exit_code':proc.returncode,'elapsed_seconds':round(time.time()-started,3)})
 pathlib.Path('/tmp/rrc-parity-startup-local-verification.json').write_text(json.dumps({'source_dir':str(r),'checks':results},indent=2)+'\n')
 print('END',name,proc.returncode,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
