use std::sync::{Arc, atomic::AtomicBool};
use vesper_harness::release_executor::{NativeReleaseExecutor, ReleaseExecutionPort};
fn main() {
 let executor=NativeReleaseExecutor::new(std::path::Path::new("/tmp/rrc-public-validation-u97tsy8b"), Arc::new(AtomicBool::new(false))).unwrap();
 let receipt=executor.publication("99percentgrip/agent-vesper-rrc-public-acceptance", "v0.24.4", "35026933eff7720c98c6cc2c5d39732e325a9e6a").unwrap().expect("controlled current-source test release");
 println!("Read-only native verifier: version={} workflow_run={} assets={}; exact annotated tag, stable metadata, server archive digests and downloaded checksum contents PASS",receipt.version,receipt.run_id,receipt.assets.len());
 println!("Current controlled public test publication only; production repository and installed application remain unchanged.");
}
