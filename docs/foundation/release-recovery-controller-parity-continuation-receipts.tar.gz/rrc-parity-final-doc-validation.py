import hashlib,json,pathlib,re,subprocess,urllib.parse
root=pathlib.Path('/home/Alex/Projects/agent-vesper')
clone=pathlib.Path('/tmp/rrc-public-validation-u97tsy8b')
sha='bd24bb48765d73c704fb81945ca87e33d093e121'
prd='docs/Agent_Vesper_Release_Recovery_Controller_PRD.md'
a=(root/prd).read_bytes().split(b'## 37.')[0]
b=subprocess.check_output(['git','show',sha+':'+prd],cwd=clone).split(b'## 37.')[0]
assert a==b
paths=[root/prd,root/'docs/AGENTS.md',root/'docs/foundation/AGENTS.md',root/'docs/foundation/evidence-index.md',root/'docs/foundation/release-recovery-controller-parity-continuation.md']
errors=[];links=0
for p in paths:
 text=p.read_text()
 for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
  target=target.strip('<>')
  if re.match(r'[A-Za-z][A-Za-z0-9+.-]*:',target) or target.startswith('#'):continue
  local=urllib.parse.unquote(target.split('#')[0])
  if not local:continue
  links+=1
  if not (p.parent/local).exists():errors.append({'path':str(p),'target':target})
trace=json.loads((root/'docs/foundation/release-recovery-controller-parity-continuation-requirements.json').read_text())
assert len(trace['sections'])==36 and len(trace['acceptance_criteria'])==23
for name in ['release-recovery-controller-parity-continuation-source.json','release-recovery-controller-parity-continuation-requirements.json']:json.loads((root/'docs/foundation'/name).read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='0b5630d271965e7d9df3a0a09c116c7f8c44042e'
out={'binding_sections_1_through_36_unchanged':True,'binding_sha256':hashlib.sha256(a).hexdigest(),'local_link_count':links,'local_link_errors':errors,'sections':36,'acceptance_criteria':23,'json_parsed':True,'primary_head_unchanged':head,'scope':'static delivery document review; no program suites rerun for prose changes'}
pathlib.Path('/tmp/rrc-parity-startup-final-delivery-doc-validation.json').write_text(json.dumps(out,indent=2)+'\n')
assert not errors,errors
print(json.dumps(out))
