use vesper_harness::release_recovery::{GhCliEvidenceAdapter,ReleaseRecoveryState,RetryKind,ReleaseLedger,start_release,refresh_remote_evidence};
fn main() {
 let args:Vec<String>=std::env::args().collect();let sha=&args[1];let mode=&args[2];let repo="99percentgrip/agent-vesper-rrc-public-acceptance";
 let ledger=ReleaseLedger::open(std::path::PathBuf::from(&args[3]),"current-controlled-parity").unwrap();
 let mut record=ledger.load().unwrap().unwrap_or_else(|| {let mut record=start_release("current-controlled-parity","patch","main",sha).unwrap();record.objective.required_gate_names=vec!["rrc-controlled-acceptance".into()];record.state=ReleaseRecoveryState::RemoteGateRunning;record});
 if !matches!(record.state, ReleaseRecoveryState::RemoteGateRunning|ReleaseRecoveryState::WaitingForMatrix) {
  record.transition(ReleaseRecoveryState::RemoteGateRunning,sha,"resume refreshes exact-SHA evidence before progression",vec!["rrc:resume-refresh".into()],None).unwrap();
 }
 refresh_remote_evidence(&mut record,repo,&GhCliEvidenceAdapter).unwrap();
 assert!(record.matrix_complete());assert_eq!(record.required_gates[0].jobs.len(),5);
 if mode=="green" {assert_eq!(record.state,ReleaseRecoveryState::RemoteGatesGreen);println!("PASS: exact SHA {sha}; controlled run {:?}; five terminal green jobs",record.required_gates[0].run_id);}
 else {assert_eq!(record.state,ReleaseRecoveryState::ClassifyingFailure);assert!(record.failures.last().unwrap().causal_excerpt.contains("rrc_fixture_assertion_42"));assert!(!record.retry_admission(RetryKind::FullGate).admitted);
 if mode=="repeat" {assert!(record.failures.len()>=2);assert_eq!(record.failures[0].fingerprint,record.failures.last().unwrap().fingerprint);assert!(record.retry_admission(RetryKind::FullGate).reason.contains("identical failure fingerprint"));}
 println!("PASS: exact SHA {sha}; controlled run {:?}; canonical workflow, causal evidence, redaction and retry refusal; fingerprint={}; cause records={}",record.required_gates[0].run_id,record.failures.last().unwrap().fingerprint.0,record.failures.len());}
 assert!(!format!("{record:#?}").contains("github_pat_RRCACCEPTANCE"));assert!(!record.render_status().contains("github_pat_RRCACCEPTANCE"));ledger.save(&record).unwrap();
 println!("Synthetic acceptance ledger only; no provider or GitHub write through the native controller.");
}
