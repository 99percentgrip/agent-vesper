use vesper_harness::release_recovery::{GhCliEvidenceAdapter, GitHubEvidencePort, first_causal_excerpt, redact_secrets};
fn main() {
 let log = GhCliEvidenceAdapter.job_log("99percentgrip/agent-vesper-rrc-acceptance",111672553145).expect("actual missing runner log annotations");
 let cause=first_causal_excerpt(&log);
 assert!(cause.contains("No space left on device"));
 assert!(log.contains("Job log unavailable"));
 println!("PASS: actual unavailable job log recovered its causal disk-full GitHub annotation\n{}",cause);
 let start=std::time::Instant::now();
 for _ in 0..1000 { assert!(redact_secrets("GH_TOKEN=[REDACTED] }
 println!("1000 cached redactions: {} ms",start.elapsed().as_millis());
}
