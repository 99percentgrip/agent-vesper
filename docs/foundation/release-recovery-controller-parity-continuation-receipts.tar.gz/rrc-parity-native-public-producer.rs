use std::{path::Path, sync::{Arc, atomic::AtomicBool}};
use vesper_harness::release_executor::{advance_release, ExternalHealthPort, NativeReleaseExecutor, OfficialStatusSnapshot, ReleaseAdvanceContext};
use vesper_harness::release_recovery::{apply_controller_event, refresh_remote_evidence, start_release, GhCliEvidenceAdapter, GitHubEvidencePort, ReleaseControllerEvent, ReleaseLedger, ReleaseRecoveryState, RrcError};
struct NoHealth;
impl ExternalHealthPort for NoHealth {
 fn official_status(&self)->Result<OfficialStatusSnapshot,RrcError>{panic!("publication cannot invent an outage")}
}
fn main() {
 let args:Vec<String>=std::env::args().collect();
 let workspace=Path::new(&args[1]); let sha=&args[2]; let mode=&args[3];
 let repo="99percentgrip/agent-vesper-rrc-public-acceptance";
 let ledger=ReleaseLedger::open(std::path::PathBuf::from(&args[4]),"controlled-public-producing-acceptance").unwrap();
 let owner_path=std::path::PathBuf::from(&args[4]).join("afe6d3fac114819c73f1a9ccfa175bea64774e32089361432b8dff62dcd90a8d.owner");
 let _owner=std::fs::OpenOptions::new().create(true).truncate(false).read(true).write(true).open(owner_path).unwrap();
 fs2::FileExt::try_lock_exclusive(&_owner).unwrap();
 let cancelled=Arc::new(AtomicBool::new(false));
 let executor=NativeReleaseExecutor::new(workspace, Arc::clone(&cancelled)).unwrap();
 let mut record=if mode=="observe" {
  assert!(ledger.load().unwrap().is_none(),"do not overwrite a producing epoch");
  assert_eq!(GhCliEvidenceAdapter.current_main_commit(repo).unwrap().as_deref(),Some(sha.as_str()));
  let head=std::process::Command::new("git").args(["rev-parse","HEAD"]).current_dir(workspace).output().unwrap();
  assert!(head.status.success()); assert_eq!(String::from_utf8(head.stdout).unwrap().trim(),sha);
  assert!(std::fs::read_to_string(workspace.join("Cargo.toml")).unwrap().contains("version = \"0.24.4\""));
  let mut row=start_release("controlled-public-producing-acceptance","patch","main",sha).unwrap();
  row.state=ReleaseRecoveryState::RemoteGateRunning;
  row.release_version=Some("0.24.4".into());
  // These facts are independently observed above from local Git and current remote main.
  row.mutation.candidate_committed=true; row.mutation.candidate_pushed=true;
  row.mutation.candidate_push_ref=Some(format!("github:{repo}:main@{sha}"));
  refresh_remote_evidence(&mut row,repo,&GhCliEvidenceAdapter).unwrap();
  assert!(row.matrix_complete());assert_eq!(row.state,ReleaseRecoveryState::RemoteGatesGreen);
  ledger.save(&row).unwrap();row
 } else {ledger.load().unwrap().expect("observed producing epoch")};
 assert_eq!(record.release_commit.as_deref(),Some(sha.as_str()));
 if mode=="tag" {
  assert_eq!(record.state,ReleaseRecoveryState::RemoteGatesGreen);
  record.transition(ReleaseRecoveryState::RemoteGateRunning,sha,"resume refreshes exact-SHA evidence before progression",vec!["rrc:resume-refresh".into()],None).unwrap();
  refresh_remote_evidence(&mut record,repo,&GhCliEvidenceAdapter).unwrap();
  assert_eq!(record.state,ReleaseRecoveryState::RemoteGatesGreen);
  assert!(record.mutation.in_flight_operation.is_none());
  record.mutation.in_flight_operation=Some("CreateTag: explicit controlled-public acceptance authorization".into());
  ledger.save(&record).unwrap();
 } else if mode=="closeout" {
  assert_eq!(record.state,ReleaseRecoveryState::Published);
  apply_controller_event(&mut record,ReleaseControllerEvent::PostReleaseCloseoutStarted(vec!["acceptance:explicit-post-publication-closeout".into()])).unwrap();
  ledger.save(&record).unwrap();
 } else {assert!(mode=="observe" || mode=="poll");}
 if mode!="observe" {
  advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&GhCliEvidenceAdapter,health:&NoHealth,repair_factory:None,cancelled}).unwrap();
  if mode=="tag" {assert_eq!(record.state,ReleaseRecoveryState::Publishing);record.mutation.in_flight_operation=None;ledger.save(&record).unwrap();}
 }
 println!("Controlled public native controller: source={sha}; mode={mode}; state={:?}; tag={:?}; tag_object={:?}; publication_run={:?}; verified_assets={}",record.state,record.mutation.tag_name,record.mutation.tag_object,record.mutation.publication_run_id,record.mutation.published_asset_names.len());
 for gate in &record.required_gates {println!("Gate {} run={:?} attempt={:?} jobs={} complete={} failed={}",gate.name,gate.run_id,gate.run_attempt,gate.jobs.len(),gate.matrix_complete(),gate.has_failure());}
 println!("Production repository, installed application and provider credentials untouched.");
}
