use vesper_harness::release_recovery::{GhCliEvidenceAdapter, ReleaseDirective, ReleaseFailureClass, ReleaseRecoveryState, RetryKind, first_causal_excerpt, classify_failure, next_directive, refresh_remote_evidence, start_release};
fn main() {
    let repository = "99percentgrip/agent-vesper-rrc-acceptance";
    let sha = "c802e93ea7ce53f97f84fdc39ac15287170a049c";
    let mut record = start_release("account-restriction-acceptance", "patch", "main", sha).unwrap();
    record.objective.required_gate_names = vec!["rrc-host-lifecycle-acceptance".into()];
    record.state = ReleaseRecoveryState::RemoteGateRunning;
    refresh_remote_evidence(&mut record, repository, &GhCliEvidenceAdapter).unwrap();
    assert!(record.matrix_complete());
    assert_eq!(record.required_gates[0].run_id, Some(37300015141));
    assert_eq!(record.required_gates[0].jobs.len(), 5);
    assert_eq!(record.state, ReleaseRecoveryState::ClassifyingFailure);
    assert!(!record.failures.is_empty());
    for failure in &record.failures {
        assert!(failure.causal_excerpt.contains("spending limit needs to be increased"));
        assert_eq!(classify_failure(&first_causal_excerpt(&failure.causal_excerpt), None).0, ReleaseFailureClass::CredentialOrPermissionFailure);
        assert_eq!(failure.class, ReleaseFailureClass::CredentialOrPermissionFailure);
    }
    assert_eq!(next_directive(&record, 0), ReleaseDirective::Escalate);
    assert!(!record.retry_admission(RetryKind::FullGate).admitted);
    assert!(!record.retry_admission(RetryKind::Infrastructure).admitted);
    println!("PASS: actual run 37300015141; complete five-job billing restriction; 404 logs recovered from owned failure annotations; truthful account classification; owner-action escalation; source repair, outage and full/infrastructure retry refused. No native body ran and no provider or GitHub writes were made.");
}
