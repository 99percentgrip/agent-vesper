import hashlib,io,json,pathlib,re,subprocess,tarfile
meta_path=pathlib.Path('/tmp/rrc-parity-public-bootstrap.json');m=json.loads(meta_path.read_text());dst=pathlib.Path(m['candidate_dir']);root=pathlib.Path('/home/Alex/Projects/agent-vesper')
public_note='''# Controlled public RRC validation

This repository is an isolated copy of Agent Vesper for controlled RRC workflow,
process, repair and publication acceptance. Test releases are validation artifacts.
Use https://github.com/99percentgrip/agent-vesper for supported installations.

The runtime source matches the locally verified RRC/OpenAI authentication repair.
Local evidence: complete `cargo xtask verify`, 64 exact acceptance cases,
77 dedicated RRC cases on stable/MSRV and 12 authentication UI cases passed.
Current native/prerequisite/producing workflow evidence is still pending.

Detailed pre-public audit receipts remain in the owner's workspace. This public
copy does not publish those private diagnostic archives or financial annotations.
Binding RRC PRD sections 1–36 remain unchanged.
'''
for name in m['scoped_paths']:
 if name.startswith('docs/foundation/release-recovery-controller-'):
  p=dst/name
  if p.suffix=='.md':p.write_text(public_note)
  elif p.suffix=='.json':p.write_text(json.dumps({'status':'local_receipts_retained_in_owner_workspace','scope':'public test snapshot; not a publication or completion receipt'},indent=2)+'\n')
  elif name.endswith('.tar.gz'):
   data=public_note.encode();info=tarfile.TarInfo('public-evidence-scope.md');info.size=len(data)
   with tarfile.open(p,'w:gz') as t:t.addfile(info,io.BytesIO(data))
p=dst/'docs/Agent_Vesper_Release_Recovery_Controller_PRD.md';s=p.read_text();i=s.index('## 37.');p.write_text(s[:i]+'## 37. Current acceptance status\n\n'+public_note)
p=dst/'docs/foundation/evidence-index.md';s=p.read_text();i=s.index('## Release Recovery Controller final completion');p.write_text('# Foundation Evidence Index\n\n## Public RRC validation\n\n'+public_note+'\n'+s[i:])
# Inspect only files that differ from the already-public committed source.
base=subprocess.check_output(['git','ls-tree','-rz','HEAD'],cwd=root)
public={entry.split(b'\t',1)[1].decode():entry.split(b'\t',1)[0].split()[2].decode() for entry in base.split(b'\0') if entry}
changed=[];flags=[];tokens=[]
pattern=re.compile(rb'(?:github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|(?:sk|xai)-[A-Za-z0-9_-]{20,})')
for p in sorted(dst.rglob('*')):
 if not p.is_file() or '.git' in p.parts:continue
 rel=p.relative_to(dst).as_posix();data=p.read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if public.get(rel)==oid:continue
 changed.append(rel)
 if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',data):flags.append({'path':rel,'kind':'private_key'})
 if rel.endswith('.tar.gz'):
  with tarfile.open(p) as t:
   for member in t:
    assert member.name=='public-evidence-scope.md'
 if '/.config/' in '/'+rel or rel.endswith(('.env','.pem')):flags.append({'path':rel,'kind':'unexpected_state'})
 for match in pattern.finditer(data):
  token=match.group().decode();line=data[:match.start()].count(b'\n')+1
  synthetic=any(x in token.lower() for x in ('test','fixture','canary','fake','dummy','example','rrc','secret','colored','mustnotleak'))
  synthetic = synthetic or (rel.startswith('docs/') and token.startswith('xai-provider-')) or hashlib.sha256(match.group()).hexdigest() in {'ae8754608195aafb81001fbdb911f6019eb8b13fa6e5ef7229ea71b0b9a7f976','d66f4cc7d7c08ec57ca73717f8625478602fd28781494d2876f871b01f4f35b9','f0a5c7674b48a1ba77463fba2c131b4bd2dc7cd7ac46607beabefea55abefced'} # reviewed literals in redaction tests
  tokens.append({'path':rel,'line':line,'synthetic_marker':synthetic,'sha256':hashlib.sha256(match.group()).hexdigest()})
  if not synthetic:flags.append({'path':rel,'line':line,'kind':'unreviewed_token_shape','sha256':hashlib.sha256(match.group()).hexdigest()})
receipt={'changed_from_public_base':changed,'token_shapes':tokens,'unresolved_flags':flags,'private_git_history_included':False,'private_audit_archives_included':False,'runtime_matches_private_candidate':[]}
for name in m['scoped_paths']:
 if name.startswith('docs/') or name.endswith('AGENTS.md') or name=='.github/workflows/release-recovery-lifecycle-acceptance.yml':continue
 expected=subprocess.check_output(['git','show',m['previous_private_candidate_sha']+':'+name],cwd='/tmp/rrc-deep-debug-candidate-t5y6m_hq');assert expected==(dst/name).read_bytes(),name;receipt['runtime_matches_private_candidate'].append(name)
pathlib.Path('/tmp/rrc-parity-public-sensitive-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Changed files:',len(changed),'Synthetic token-shaped fixtures:',len(tokens),'Unresolved flags:',len(flags));print(json.dumps(flags,indent=2))
assert not flags,'Resolve sensitive-material flags before public push'
