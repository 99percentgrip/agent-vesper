use vesper_harness::release_recovery::{GhCliEvidenceAdapter, GitHubEvidencePort, ReleaseRecoveryState, RetryKind, start_release, refresh_remote_evidence};
fn main() {
 let sha=std::env::args().nth(1).unwrap(); let repo="99percentgrip/agent-vesper-rrc-acceptance"; let adapter=GhCliEvidenceAdapter;
 let mut record=start_release("controlled-partial-audit","patch","main",&sha).unwrap(); record.objective.required_gate_names=vec!["rrc-controlled-acceptance".into()]; record.state=ReleaseRecoveryState::RemoteGateRunning;
 let mut partial=false;
 for _ in 0..8 {
  let gates=adapter.matrix_for_sha(repo,&sha).unwrap();
  if let Some(gate)=gates.iter().find(|g|g.name=="rrc-controlled-acceptance") {
   if gate.has_failure() && !gate.matrix_complete() {
    refresh_remote_evidence(&mut record,repo,&adapter).unwrap();
    if record.state==ReleaseRecoveryState::ClassifyingFailure {
      assert!(partial, "first snapshot was superseded before a partial state could be validated");
      assert!(record.required_gates.iter().all(|g|g.matrix_complete()));
      assert_eq!(record.failures.len(),1);
      println!("Fresh matrix settled between observations; diagnosis followed fresh terminal receipt; PASS"); return;
    }
    assert_eq!(record.state,ReleaseRecoveryState::WaitingForMatrix);
    assert!(!record.retry_admission(RetryKind::FullGate).admitted);
    assert!(record.failures.is_empty());
    println!("Actual partial matrix: sha={sha} run={:?} jobs={:?}; WaitingForMatrix, no diagnosis capture, retry denied",gate.run_id,gate.jobs.iter().map(|j|(j.job_id,j.state)).collect::<Vec<_>>()); partial=true;
   }
   if gate.matrix_complete() {
    assert!(partial,"must observe actual failed-plus-running matrix");
    refresh_remote_evidence(&mut record,repo,&adapter).unwrap();
    assert_eq!(record.state,ReleaseRecoveryState::ClassifyingFailure);
    assert_eq!(record.failures.len(),1);
    assert!(record.failures[0].causal_excerpt.contains("rrc_fixture_assertion_42"));
    println!("Actual settled matrix: sha={sha} run={:?}; cause captured only after settlement; PASS",gate.run_id); return;
   }
  }
  std::thread::sleep(std::time::Duration::from_secs(20));
 }
 panic!("controlled matrix did not settle within bounded probe");
}
