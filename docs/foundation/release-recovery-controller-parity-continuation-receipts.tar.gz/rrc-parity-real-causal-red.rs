use vesper_harness::release_recovery::{first_causal_excerpt,classify_failure,ReleaseFailureClass,EvidenceConfidence};
fn main() {
 let log=std::fs::read_to_string("/tmp/rrc-parity-final-canonical-failed.log").unwrap();
 let excerpt=first_causal_excerpt(&log);
 println!("Current first causal excerpt: {}",excerpt.lines().take(3).collect::<Vec<_>>().join("\n"));
 let (class, confidence)=classify_failure("unrecognized terminal job message",Some("ubuntu-24.04"));
 println!("Unrecognized message with platform metadata: {class:?}/{confidence:?}");
 assert!(excerpt.contains("linking with") || excerpt.contains("ld terminated with signal 7"),"successful error:: test names hid the later real linker failure");
 assert_eq!((class,confidence),(ReleaseFailureClass::Unknown,EvidenceConfidence::Unknown));
}
