use vesper_harness::release_recovery::{GhCliEvidenceAdapter,GitHubEvidencePort,ReleaseRecoveryState,RetryKind,start_release,refresh_remote_evidence};
fn main() {
 let args:Vec<String>=std::env::args().collect();let sha=&args[1];let expected=&args[2];let repo="99percentgrip/agent-vesper-rrc-acceptance";let adapter=GhCliEvidenceAdapter;
 let mut record=start_release("current-controlled-parity","patch","main",sha).unwrap();record.objective.required_gate_names=vec!["rrc-controlled-acceptance".into()];record.state=ReleaseRecoveryState::RemoteGateRunning;
 refresh_remote_evidence(&mut record,repo,&adapter).unwrap();
 assert!(record.matrix_complete());assert_eq!(record.required_gates[0].jobs.len(),5);
 if expected=="red" {assert_eq!(record.state,ReleaseRecoveryState::ClassifyingFailure);assert_eq!(record.failures.len(),1);assert!(record.failures[0].causal_excerpt.contains("rrc_fixture_assertion_42"));assert!(!record.retry_admission(RetryKind::FullGate).admitted);println!("PASS: exact SHA {} controlled run {:?}; jobs=5; actual causal error, canonical workflow ID, redaction and no-proof retry refusal; fingerprint={}",sha,record.required_gates[0].run_id,record.failures[0].fingerprint.0);}
 else {assert_eq!(record.state,ReleaseRecoveryState::RemoteGatesGreen);println!("PASS: exact SHA {} controlled run {:?}; five terminal green jobs",sha,record.required_gates[0].run_id);}
 let encoded=format!("{record:#?}");assert!(!encoded.contains("github_pat_RRCACCEPTANCE"));assert!(!record.render_status().contains("github_pat_RRCACCEPTANCE"));
 std::fs::write(&args[3],format!("{record:#?}")).unwrap();
}
