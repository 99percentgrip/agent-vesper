import gdb
for i in range(50):
    result=gdb.execute('run',to_string=True)
    threads=gdb.selected_inferior().threads()
    if threads:
        print('Stopped live inferior at iteration',i+1)
        print(result[-6000:])
        print(gdb.execute('thread apply all bt',to_string=True))
        break
    print('Iteration',i+1,'exited normally')
else:
    print('No crash reproduced in 50 debugger runs')
