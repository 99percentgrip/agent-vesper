import json,os,pathlib,subprocess,sys,time
repo='99percentgrip/agent-vesper-rrc-public-acceptance'
mode,identity,sha,prefix=sys.argv[1:]
env=os.environ.copy();env['GODEBUG']='http2client=0'
def gh(args):
 return json.loads(subprocess.check_output(['gh',*args,'--repo',repo],env=env))
started=time.time();previous=None
while time.time()-started<3600:
 if mode=='native':
  runs=[gh(['run','view',identity,'--json','databaseId,status,conclusion,headSha,jobs,url,workflowName'])]
 else:
  rows=gh(['run','list','--commit',sha,'--branch','main','--event','push','--limit','30','--json','databaseId,workflowName,status,conclusion,headSha'])
  expected={'pull-request-validation':2,'msrv':1,'five-target-foundation':5,'web-driver':3}
  rows=[r for r in rows if r['workflowName'] in expected]
  runs=[gh(['run','view',str(row['databaseId']),'--json','databaseId,status,conclusion,headSha,jobs,url,workflowName']) for row in rows]
 for run in runs:assert run['headSha']==sha
 snapshot={'source_sha':sha,'mode':mode,'runs':runs}
 pathlib.Path(prefix+'-matrix-progress.json').write_text(json.dumps(snapshot,indent=2)+'\n')
 statuses=[(r['databaseId'],r['workflowName'],r['status'],r['conclusion'],[(j['name'],j['status'],j['conclusion']) for j in r['jobs']]) for r in runs]
 if statuses!=previous:print(json.dumps(statuses),flush=True);previous=statuses
 complete=len(runs)==(1 if mode=='native' else 4) and all(r['status']=='completed' and all(j['status']=='completed' for j in r['jobs']) for r in runs)
 if complete:
  for r in runs:assert len(r['jobs'])==(5 if mode=='native' else expected[r['workflowName']])
  pathlib.Path(prefix+'-settled.json').write_text(json.dumps(snapshot,indent=2)+'\n')
  ok=all(r['conclusion']=='success' and all(j['conclusion']=='success' for j in r['jobs']) for r in runs)
  print('SETTLED',ok,flush=True);raise SystemExit(0 if ok else 1)
 time.sleep(45)
raise SystemExit('matrix did not settle within the monitoring bound')
