use std::{path::{Path,PathBuf},sync::Arc};
use vesper_harness::{WorkerFactory,release_executor::{spawn_release_worker_with_factory,active_release_worker},release_recovery::{ReleaseLedger,ReleaseRecoveryState,repository_identity_for_workspace,default_release_root}};
use vesper_agent::{AgentLoopConfig,PermissionPort,PermissionDecision,ToolFuture,ToolContext};
use vesper_domain::{ToolCall,ToolDefinition,ProviderId,ModelId,QualifiedModelId,WorkspaceRoot,SessionOperatingMode,SessionPermissionMode};
struct AuthorizedRelease {sha:String,workspace:String}
impl PermissionPort for AuthorizedRelease {
 fn authorize<'a>(&'a self,call:&'a ToolCall,_definition:&'a ToolDefinition,context:&'a ToolContext)->ToolFuture<'a,PermissionDecision> {
  Box::pin(async move {
   let preparing = call.arguments.get("stage").and_then(|x|x.as_str())==Some("LocalVerification") && call.arguments.get("version").is_some_and(|x|x.is_null());
   let scoped=call.tool_id.as_str()=="release_controller" && call.arguments.get("candidate").and_then(|x|x.as_str())==Some(self.sha.as_str()) && (call.arguments.get("version").and_then(|x|x.as_str())==Some("0.24.5") || preparing) && context.workspace_roots.first().is_some_and(|x|x.path.as_str()==self.workspace);
   if !scoped {return PermissionDecision::Deny("outside explicit v0.24.5 release authorization".into());}
   let stage=call.arguments.get("stage").and_then(|x|x.as_str()).unwrap_or("");
   let operation=call.arguments.get("operation").and_then(|x|x.as_str()).unwrap_or("");
   if stage=="RemoteGatesGreen" {
    let marker=std::fs::read("/tmp/vesper-release-current-controlled-complete.json").ok().and_then(|b|serde_json::from_slice::<serde_json::Value>(&b).ok());
    if !marker.is_some_and(|x|x.get("candidate_sha").and_then(|v|v.as_str())==Some(self.sha.as_str()) && x.get("passed").and_then(|v|v.as_bool())==Some(true)) {return PermissionDecision::Deny("current-source controlled acceptance remains unexecuted; publication stays gated".into());}
   }
   if matches!(stage,"LocalVerification"|"CandidateReady"|"RemoteGatesGreen") || (stage=="ClassifyingFailure" && operation.starts_with("rerun the exact admitted")) {
    println!("User-authorized native release operation: {stage}: {operation}");PermissionDecision::Allow
   } else {PermissionDecision::Deny("coding repair requires a configured active provider host; no provider is mocked by this producer".into())}
  })
 }
}
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),3,"workspace candidate-sha");let source=Path::new(&args[1]);let sha=&args[2];let identity=repository_identity_for_workspace(source)?;
 let root=default_release_root().expect("native state root");assert_eq!(root,PathBuf::from("/home/Alex/.local/state/agent-vesper/release-recovery"));let ledger=ReleaseLedger::open(root,&identity)?;let record=ledger.load()?.expect("admitted native epoch");assert_eq!(record.active_commit(),Some(sha.as_str()));assert_eq!(record.objective.version.as_str(),"0.24.5","helper authorization binds admitted exact target before version preparation");assert!(record.mutation.in_flight_operation.is_none());
 let workspace=PathBuf::from(record.mutation.release_workspace.expect("owned release workspace"));let workspace_string=workspace.to_string_lossy().into_owned();
 // This caller carries actual user authorization for native release operations.
 // No model transport is configured; unexpected coding repair refuses truthfully.
 // Unused configuration values are real catalog metadata, never invented models.
 let provider=ProviderId::new("zai")?;
 let config=AgentLoopConfig{provider_id:provider.clone(),provider_configuration:vesper_provider::ProviderConfiguration{provider_id:provider.clone(),values:vesper_domain::VersionedExtensionEnvelope{namespace:vesper_domain::ExtensionNamespace::new("provider.zai")?,version:vesper_domain::SchemaVersion::new(1).expect("nonzero schema"),values:Default::default()}},model:QualifiedModelId{provider_id:provider,model_id:ModelId::new("glm-5.2")?},context_window_tokens:1_000_000,native_compaction:vesper_agent::NativeCompactionPolicy::Disabled,hosted_tools:Vec::new(),system_instructions:Vec::new(),workspace_roots:vec![WorkspaceRoot{name:vesper_domain::BoundedString::new("native release workspace")?,path:vesper_domain::BoundedString::new(workspace_string.clone())?,primary:true}],max_tool_iterations:24,firewall:None,sandbox:None};
 let factory=WorkerFactory::new(Arc::new(vesper_runtime::ProviderRegistry::new()),config).with_permission_port(Arc::new(AuthorizedRelease{sha:sha.clone(),workspace:workspace_string})).with_release_policy(SessionOperatingMode::Code,SessionPermissionMode::Ask);
 let registration=spawn_release_worker_with_factory(workspace,"99percentgrip/agent-vesper".into(),identity.clone(),Some(factory))?;println!("Registered native controller: {}",registration.epoch_id);
 let mut previous=String::new();loop {
  if let Some(s)=active_release_worker(&identity) {
   let summary=format!("{} | {} | gates {}/{} | gate {:?} | child {:?} | quiet {}s",s.stage,s.detail,s.completed_gates,s.total_gates,s.current_gate,s.current_child,s.last_activity_ago_secs);
   if summary!=previous {println!("{summary}");for line in s.recent_output.iter().rev().take(2).rev(){println!("{line}");}previous=summary;}
  } else {break;}
  std::thread::sleep(std::time::Duration::from_secs(5));
 }
 let record=ledger.load()?.expect("settled native epoch");println!("Native controller settled: {:?}\n{}",record.state,record.render_status());
 if matches!(record.state,ReleaseRecoveryState::PausedExternal|ReleaseRecoveryState::Published|ReleaseRecoveryState::Complete|ReleaseRecoveryState::RemoteGatesGreen) {Ok(())} else {Err(format!("native controller requires evidence at {:?}",record.state).into())}
}
