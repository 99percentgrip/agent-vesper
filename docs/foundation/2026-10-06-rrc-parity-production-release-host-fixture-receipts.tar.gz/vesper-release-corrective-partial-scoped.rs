use vesper_harness::release_recovery::{GhCliEvidenceAdapter,ReleaseRecoveryState,RetryKind,start_release,refresh_remote_evidence,GitHubEvidencePort,GateRecord,RrcError};

struct IntendedRun(u64);
impl GitHubEvidencePort for IntendedRun {
 fn matrix_for_sha(&self,repo:&str,sha:&str)->Result<Vec<GateRecord>,RrcError>{Ok(GhCliEvidenceAdapter.matrix_for_sha(repo,sha)?.into_iter().filter(|g|g.run_id==Some(self.0)).collect())}
 fn job_log(&self,repo:&str,id:u64)->Result<String,RrcError>{GhCliEvidenceAdapter.job_log(repo,id)}
 fn rerun_job(&self,repo:&str,id:u64)->Result<(),RrcError>{GhCliEvidenceAdapter.rerun_job(repo,id)}
 fn rerun_failed(&self,repo:&str,id:u64)->Result<(),RrcError>{GhCliEvidenceAdapter.rerun_failed(repo,id)}
 fn rerun_workflow(&self,repo:&str,id:u64)->Result<(),RrcError>{GhCliEvidenceAdapter.rerun_workflow(repo,id)}
}
fn main(){
 let args:Vec<_>=std::env::args().collect();let sha=&args[1];let expected:u64=args[2].parse().unwrap();
 let mut record=start_release("controlled-partial-current","patch","main",sha).unwrap();record.objective.required_gate_names=vec!["rrc-controlled-acceptance".into()];record.state=ReleaseRecoveryState::RemoteGateRunning;
 let mut observed_partial=false;
 for _ in 0..180 {
  refresh_remote_evidence(&mut record,"99percentgrip/agent-vesper-rrc-public-acceptance",&IntendedRun(expected)).unwrap();
  if let Some(gate)=record.required_gates.iter().find(|g|g.run_id==Some(expected)) {
   if gate.has_failure() && !gate.matrix_complete() {
    assert_eq!(record.state,ReleaseRecoveryState::WaitingForMatrix);assert!(record.failures.is_empty());assert!(!record.retry_admission(RetryKind::FullGate).admitted);
    println!("Actual native partial matrix: sha={sha} run={expected} jobs={:?}; WaitingForMatrix, no captured causes, retry denied",gate.jobs.iter().map(|j|(j.job_id,j.state)).collect::<Vec<_>>());observed_partial=true;
   }
   if gate.matrix_complete(){assert!(observed_partial,"actual partial state must have been observed, not inferred");assert_eq!(record.state,ReleaseRecoveryState::ClassifyingFailure);assert_eq!(record.failures.len(),1);assert!(record.failures[0].causal_excerpt.contains("rrc_fixture_assertion_42"));println!("Actual settled native matrix: sha={sha} run={expected}; cause captured only after complete matrix; PASS");return;}
  }
  std::thread::sleep(std::time::Duration::from_secs(5));
 }
 panic!("actual partial/terminal observations did not settle within bound");
}
