from pathlib import Path
import json,subprocess,hashlib
root=Path('/tmp/vesper-registry-production-release');receipt=json.loads(Path('/tmp/vesper-release-published-assets-verification.json').read_text());assert receipt['passed'] and receipt['candidate_sha']=='7e837db36f4090e566ac1a7461b5b103b8649368'
assets={a['name']:a for a in receipt['assets']};v=json.loads(subprocess.check_output(['git','show','HEAD:agent-vesper/agent.json'],cwd=root));assert v['version']=='0.24.4';v['version']='0.24.5'
for platform,entry in v['distribution']['binary'].items():
 name=entry['archive'].rsplit('/',1)[-1];entry['archive']=entry['archive'].replace('/v0.24.4/','/v0.24.5/');entry['sha256']=assets[name]['sha256']
(root/'agent-vesper/agent.json').write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
matrix=json.loads(Path('/tmp/vesper-release-windows-sse-production-matrix.json').read_text());assert all(r['conclusion']=='success' for r in matrix)
body='''## What

Adds Agent Vesper **v0.24.5** to the public ACP Registry, updating this existing PR in place.

Agent Vesper is a Rust-native ACP v1 coding-agent runtime with a bundled native TUI,
provider-routed authentication, reasoning orchestration, transactional sessions,
cognitive memory, semantic context compaction and provider-neutral skill routing.
The registered adapters are Z.ai, native OpenAI, xAI / Grok and LM Studio.

- Repository: https://github.com/99percentgrip/agent-vesper
- Release: https://github.com/99percentgrip/agent-vesper/releases/tag/v0.24.5
- License: Apache-2.0
- Five native platform archives; each manifest entry pins its downloaded SHA-256.
- Required monochrome 16×16 icon retained.

## Manifest

```json
'''+json.dumps(v,indent=2,ensure_ascii=False)+'''\n```

## Verification

- Registry schema, distribution versions, icon and actual published URLs validated.
- All eleven exact-commit prerequisite jobs passed before the immutable release tag.
- Actual published archive bytes, seven checksum pairs and all five bundled browser-driver images verified.

Exact release source: `'''+receipt['candidate_sha']+'''`.

Prerequisite runs:
'''+''.join(f"- {r['workflow']}: https://github.com/99percentgrip/agent-vesper/actions/runs/{r['run_id']}\n" for r in matrix)
Path('/tmp/vesper-release-registry-pr-body.md').write_text(body)
print('Prepared checksum-pinned current manifest and existing PR body from actual publication evidence')
