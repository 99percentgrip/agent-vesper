import sys, importlib.util, json, pathlib, hashlib
root=pathlib.Path('/tmp/vesper-registry-production-release'); sys.path.insert(0,str(root/'.github/workflows'))
spec=importlib.util.spec_from_file_location('build_registry',root/'.github/workflows/build_registry.py'); module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
assert not module.SKIP_URL_VALIDATION
path=root/'agent-vesper/agent.json'; agent=json.loads(path.read_text()); assert agent['version']=='0.24.5'
schema=module.load_schema(root); assert schema is not None
checks={'schema_and_metadata':module.validate_agent(agent,'agent-vesper',schema),'distribution_versions':module.validate_distribution_versions(agent['version'],agent['distribution']),'icon':module.validate_icon(root/'agent-vesper/icon.svg'),'published_distribution_urls':module.validate_distribution_urls(agent['distribution'])}
receipt={'version':agent['version'],'checks':checks,'passed':not any(checks.values()),'agent_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'icon_sha256':hashlib.sha256((root/'agent-vesper/icon.svg').read_bytes()).hexdigest(),'urls':[v['archive'] for v in agent['distribution']['binary'].values()]}
pathlib.Path('/tmp/vesper-release-registry-final-validation.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt,indent=2)); assert receipt['passed'],checks
