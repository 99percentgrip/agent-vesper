from pathlib import Path
import json,hashlib,subprocess,tarfile,io,re
root=Path('/tmp');repo=Path('/tmp/vesper-production-release');dst=repo/'docs/foundation';sha='7e837db36f4090e566ac1a7461b5b103b8649368'
requirements=json.loads((root/'vesper-release-final-requirements.json').read_text());assert requirements['candidate_sha']==sha
ledger=json.loads((root/'vesper-release-final-complete-native-epoch.json').read_text());assert ledger['state']=='complete' and ledger['release_commit']==sha
registry=json.loads((root/'vesper-release-registry-final-validation.json').read_text());assert registry['passed']
pr=json.loads((root/'vesper-release-registry-delivered-pr.json').read_text());assert pr['number']==539 and pr['state']=='OPEN'
files=sorted(p for p in root.glob('vesper-release-windows-sse-*') if p.is_file() and p.suffix in ['.json','.log','.py'])
files+=sorted(p for p in root.glob('vesper-release-producing-*') if p.is_file() and p.suffix in ['.json','.log','.py'])
files+=sorted(p for p in root.glob('vesper-release-published-*') if p.is_file() and p.suffix in ['.json','.log'])
files += [root/n for n in ['vesper-release-final-complete-native-epoch.json','vesper-release-final-requirements.json','vesper-release-final-primary-preservation.json','vesper-release-registry-final-validation.json','vesper-release-registry-delivered-pr.json','vesper-release-registry-delivery.json','vesper-release-registry-pr-body.md','vesper-release-native-closeout.log','vesper-production-release-controller-v2.rs','vesper-release-registered-producer-corrective.rs','rrc-parity-public-controlled.rs','vesper-release-corrective-partial-scoped.rs','vesper-release-focused-cargo.rs','vesper-release-bd49-complete-failed-native-epoch.json']]
files += [root/n for n in ['vesper-release-verify-published-assets.py','vesper-release-probe-published-linux-version.py','vesper-release-finalize-requirement-trace.py','vesper-release-prepare-registry-delivery.py','vesper-release-registry-final-validate.py','vesper-release-build-final-evidence.py','vesper-release-finalize-report.py']]
files=list(dict.fromkeys(p for p in files if p.exists()));out=root/'vesper-release-final-sanitized';assert not out.exists()
subprocess.run(['/tmp/rrc-parity-redact-receipt',str(out),*[str(p) for p in files]],check=True,capture_output=True)
original={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files};receipts=[]
archive=dst/'2026-10-06-rrc-parity-production-release-final-receipts.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(out.iterdir()):
  b=p.read_bytes()
  if p.suffix=='.json':json.loads(b)
  entry=tarfile.TarInfo(p.name);entry.size=len(b);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(b));receipts.append({'path':p.name,'bytes':len(b),'source_sha256':original[p.name],'sha256':hashlib.sha256(b).hexdigest()})
by_name={x['path']:x for x in receipts}
for observation in requirements['native_platform_observations']:
 p=out/observation['log'];assert by_name[p.name]['source_sha256']==observation['sha256'];s=p.read_text();assert all(re.search(r'test '+re.escape(case)+r' \.\.\. ok',s) for case in observation['named_cases']);observation['archived_log_sha256']=by_name[p.name]['sha256']
(dst/'2026-10-06-rrc-parity-production-release-final-requirements.json').write_text(json.dumps(requirements,indent=2)+'\n')
source=json.loads((root/'vesper-release-windows-sse-source.json').read_text());assert source['candidate_sha']==sha
source['native_runtime_linkage']=json.loads((root/'vesper-release-windows-sse-native-linkage.json').read_text());source['registry_delivery']=json.loads((root/'vesper-release-registry-delivery.json').read_text());source['scope_limits']=requirements['scope_limits'];(dst/'2026-10-06-rrc-parity-production-release-final-source.json').write_text(json.dumps(source,indent=2)+'\n')
v={'candidate_sha':sha,'version':'0.24.5','status':'Published production release; all exact-source prerequisites and producing jobs passed; actual assets verified; native Complete; Registry PR539 updated in place.','archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'binding_prd_sha256':'e85011c696d769837c6ed5a83e4290e77eadc4ae27a9ea42cffe0966d37518db','receipts':receipts,'scope':'Original SHA256 and sanitized archived SHA256 are recorded separately. Current named-case observations are verified in archived logs. Frozen earlier companions retain historical failure and correction scope.'}
(dst/'2026-10-06-rrc-parity-production-release-final-evidence.json').write_text(json.dumps(v,indent=2)+'\n');print('Final sanitized receipts:',len(receipts),flush=True)
