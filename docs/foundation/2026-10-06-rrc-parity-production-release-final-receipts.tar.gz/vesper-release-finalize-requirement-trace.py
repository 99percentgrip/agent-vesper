import json,pathlib,re,hashlib
root=pathlib.Path('/tmp');sha='7e837db36f4090e566ac1a7461b5b103b8649368'
ledger=json.loads((root/'vesper-release-final-complete-native-epoch.json').read_text());assert ledger['state']=='complete' and ledger['release_commit']==sha and ledger['release_version']=='0.24.5';assert len(ledger['mutation']['local_gates'])==8 and all(g['state']=='succeeded' for g in ledger['mutation']['local_gates'])
matrix=json.loads((root/'vesper-release-windows-sse-production-matrix.json').read_text());assert len(matrix)==4 and sum(len(r['jobs']) for r in matrix)==11 and all(r['head_sha']==sha and r['status']=='completed' and r['conclusion']=='success' for r in matrix)
v=json.loads((root/'vesper-release-host-fixture-requirements.json').read_text());v['candidate_sha']=sha;v['status']='Current exact-source native local gates, eleven production prerequisite jobs, fresh public controls, actual production publication/assets and native Complete passed; scope exclusions remain explicit.'
v['preceding_candidate_local_acceptance_history'].append(v.pop('local_acceptance'));v['preceding_current_controlled_runs']=[v.pop('preceding_current_controlled_run'),v.pop('current_controlled_run')]
v['current_controlled_run']=json.loads((root/'vesper-release-windows-sse-controlled-complete.json').read_text());assert v['current_controlled_run']['candidate_sha']==sha and v['current_controlled_run']['passed']
names=sorted({c for item in v['sections']+v['acceptance_criteria'] for c in item['current_native_cases']});assert len(names)==85
observations=[]
for run in matrix:
 if run['workflow']=='five-target-foundation':
  assert len(run['jobs'])==5
  for job in run['jobs']:
   path=pathlib.Path(job['log']);b=path.read_bytes();assert hashlib.sha256(b).hexdigest()==job['sha256'];text=b.decode();missing=[n for n in names if not re.search(r'test '+re.escape(n)+r' \.\.\. ok',text)];assert not missing,(job['name'],missing)
   observations.append({'platform':job['name'],'job_id':job['id'],'run_id':run['run_id'],'log':path.name,'sha256':job['sha256'],'named_cases':names})
assert len(observations)==5
for item in v['sections']+v['acceptance_criteria']:
 item['current_case_observations']=[{'platform':o['platform'],'job_id':o['job_id'],'log':o['log'],'passed_cases':item['current_native_cases']} for o in observations]
 if 'historical_case_mapping_only' in item:item['historical_case_mapping_only']=False;item['scope']='Current exact-SHA named cases observed in all five native target logs; actual native/public producing receipts provide lifecycle evidence.'
v['native_platform_observations']=observations
v['local_acceptance']={'candidate_sha':sha,'local_steps':ledger['mutation']['local_gates'],'native_log':'vesper-release-windows-sse-registered-producer.log','inventory':'100 Linux exact cases executed twice: workspace verify and dedicated acceptance','scope':'Actual registered native gates and their persisted success/output digests; complete platform logs retain the named cases.'}
v['production_prerequisite_matrix']=matrix
v['publication']=json.loads((root/'vesper-release-published-assets-verification.json').read_text());assert v['publication']['candidate_sha']==sha and v['publication']['passed']
v['native_closeout']={'epoch_id':ledger['epoch_id'],'state':ledger['state'],'retry_budget':ledger['retry_budget'],'repair_attempts':ledger['repair_attempts'],'tag_name':ledger['mutation']['tag_name'],'publication_run_id':ledger['mutation']['publication_run_id']}
v['scope_limits']=['Linux host-resource discovery; non-Linux production governor refuses unavailable observations rather than fabricating health.','Sandbox repair command port lacks managed cache/environment composition and refuses governed Cargo repair before host dispatch.','Real OpenAI browser/account completion remains unexecuted.','Actual live-model repair effectiveness remains unexecuted; public controls and deterministic two-provider real-tool repair fixtures are scoped evidence.','Public controlled five-job Ubuntu labels are not native platform certification; the actual production five-platform logs above provide that evidence.','No installer or local installation replacement.']
(root/'vesper-release-final-requirements.json').write_text(json.dumps(v,indent=2)+'\n');print('Every binding section and AC mapped to 85 directly observed cases across all five exact-source native targets; production lifecycle receipts attached.')
