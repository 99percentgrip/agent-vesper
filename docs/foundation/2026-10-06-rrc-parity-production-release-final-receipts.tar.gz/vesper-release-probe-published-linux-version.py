from pathlib import Path
import json,tarfile,tempfile,subprocess,hashlib
root=Path('/tmp/vesper-release-v0.24.5-published-assets');verified=json.loads(Path('/tmp/vesper-release-published-assets-verification.json').read_text());assert verified['passed'] and verified['candidate_sha']=='7e837db36f4090e566ac1a7461b5b103b8649368'
receipts=[]
with tempfile.TemporaryDirectory(prefix='vesper-published-version-') as directory:
 fixture=Path(directory);env={'PATH':'/usr/bin:/bin','HOME':directory,'XDG_CONFIG_HOME':str(fixture/'config'),'XDG_DATA_HOME':str(fixture/'data'),'XDG_STATE_HOME':str(fixture/'state'),'AGENT_VESPER_HOME':str(fixture/'vesper-state')}
 with tarfile.open(root/'agent-vesper-acp-linux-x86_64.tar.gz') as archive:
  for name in ['agent-vesper-acp','agent-vesper-tui']:
   member=archive.getmember('agent-vesper-acp/'+name);assert member.isfile();data=archive.extractfile(member).read();binary=fixture/name;binary.write_bytes(data);binary.chmod(0o700)
   result=subprocess.run([str(binary),'--version'],cwd=fixture,env=env,capture_output=True,text=True,timeout=30);assert result.returncode==0 and (result.stdout+result.stderr).strip()==name+' 0.24.5',(name,result.returncode,result.stdout,result.stderr)
   receipts.append({'binary':name,'sha256':hashlib.sha256(data).hexdigest(),'stdout':result.stdout.strip(),'stderr':result.stderr.strip(),'exit_code':result.returncode})
 for path in ['config','data','state','vesper-state','.agent-vesper']:assert not (fixture/path).exists(),path
v={'candidate_sha':verified['candidate_sha'],'passed':True,'receipts':receipts,'scope':'Actual downloaded Linux x86_64 ACP/TUI --version in a cleared environment and temporary HOME/workspace. No installer, provider prompt or persistent user state.'}
Path('/tmp/vesper-release-published-linux-version-verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
