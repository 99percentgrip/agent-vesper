## What

Adds Agent Vesper **v0.24.5** to the public ACP Registry, updating this existing PR in place.

Agent Vesper is a Rust-native ACP v1 coding-agent runtime with a bundled native TUI,
provider-routed authentication, reasoning orchestration, transactional sessions,
cognitive memory, semantic context compaction and provider-neutral skill routing.
The registered adapters are Z.ai, native OpenAI, xAI / Grok and LM Studio.

- Repository: https://github.com/99percentgrip/agent-vesper
- Release: https://github.com/99percentgrip/agent-vesper/releases/tag/v0.24.5
- License: Apache-2.0
- Five native platform archives; each manifest entry pins its downloaded SHA-256.
- Required monochrome 16×16 icon retained.

## Manifest

```json
{
  "id": "agent-vesper",
  "name": "Agent Vesper",
  "version": "0.24.5",
  "description": "Agent Vesper — a Rust-native ACP coding-agent runtime featuring the Vesper Reasoning Orchestrator (VRO), transactional sessions, hosted tools, provider-routed authentication, cognitive memory, semantic context compaction, and provider-neutral skill orchestration. The release bundle includes a native TUI and ACP v1 stdio server with real Z.ai GLM, native OpenAI, xAI / Grok, and LM Studio adapters, installable in Zed and other ACP-compatible editors.",
  "repository": "https://github.com/99percentgrip/agent-vesper",
  "website": "https://github.com/99percentgrip/agent-vesper",
  "authors": [
    "Aleksejs Kozlitins"
  ],
  "license": "Apache-2.0",
  "license_url": "https://github.com/99percentgrip/agent-vesper/blob/main/LICENSE",
  "distribution": {
    "binary": {
      "darwin-x86_64": {
        "archive": "https://github.com/99percentgrip/agent-vesper/releases/download/v0.24.5/agent-vesper-acp-darwin-x86_64.tar.gz",
        "cmd": "./agent-vesper-acp/agent-vesper-acp",
        "sha256": "b56b93590548fb1a397af741aee705230c825ed9c031c857453ec0e27e1ac28d"
      },
      "darwin-aarch64": {
        "archive": "https://github.com/99percentgrip/agent-vesper/releases/download/v0.24.5/agent-vesper-acp-darwin-aarch64.tar.gz",
        "cmd": "./agent-vesper-acp/agent-vesper-acp",
        "sha256": "7b02fb34cfd9c5ace93707a8bbeb81d18551a65158a406ed1cd550ab1e7d82f6"
      },
      "linux-x86_64": {
        "archive": "https://github.com/99percentgrip/agent-vesper/releases/download/v0.24.5/agent-vesper-acp-linux-x86_64.tar.gz",
        "cmd": "./agent-vesper-acp/agent-vesper-acp",
        "sha256": "1656fc8d251eeb71761fc06db983d18dd5e7e151b66f1afae874a4c1af9e04c7"
      },
      "linux-aarch64": {
        "archive": "https://github.com/99percentgrip/agent-vesper/releases/download/v0.24.5/agent-vesper-acp-linux-aarch64.tar.gz",
        "cmd": "./agent-vesper-acp/agent-vesper-acp",
        "sha256": "8d523d6255fc25107d2fdfb2e862ad90c1a7c984ec44bf49698e0b12dee76c01"
      },
      "windows-x86_64": {
        "archive": "https://github.com/99percentgrip/agent-vesper/releases/download/v0.24.5/agent-vesper-acp-windows-x86_64.zip",
        "cmd": "./agent-vesper-acp/agent-vesper-acp.exe",
        "sha256": "86ac075ea968473065b8fc39b726cb78574c9b8654e208ad2bc0562fe69e01c5"
      }
    }
  }
}
```

## Verification

- Registry schema, distribution versions, icon and actual published URLs validated.
- All eleven exact-commit prerequisite jobs passed before the immutable release tag.
- Actual published archive bytes, seven checksum pairs and all five bundled browser-driver images verified.

Exact release source: `7e837db36f4090e566ac1a7461b5b103b8649368`.

Prerequisite runs:
- web-driver: https://github.com/99percentgrip/agent-vesper/actions/runs/37414452090
- msrv: https://github.com/99percentgrip/agent-vesper/actions/runs/37414452099
- pull-request-validation: https://github.com/99percentgrip/agent-vesper/actions/runs/37414452144
- five-target-foundation: https://github.com/99percentgrip/agent-vesper/actions/runs/37414452103
