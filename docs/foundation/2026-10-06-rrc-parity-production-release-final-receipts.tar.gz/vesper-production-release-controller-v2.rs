use std::{path::{Path,PathBuf}, sync::{Arc,atomic::AtomicBool}};
use vesper_harness::{host_resources::{HostResourceGovernor,ResourcePolicy},release_executor::{advance_release,CurlGitHubStatusAdapter,NativeReleaseExecutor,ReleaseAdvanceContext,ReleaseExecutionPort,production_local_gates},release_recovery::{ReleaseLedger,ReleaseRecoveryState,ReleaseControllerEvent,GhCliEvidenceAdapter,GitHubEvidencePort,start_release,apply_controller_event,refresh_remote_evidence,admit_natural_release_with_launcher,repository_identity_for_workspace,NaturalReleaseAdmission}};
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<_>=std::env::args().collect(); assert_eq!(args.len(),5,"workspace sha mode state-root");
 let workspace=Path::new(&args[1]); let sha=&args[2]; let mode=&args[3]; let root=PathBuf::from(&args[4]);
 let repo="99percentgrip/agent-vesper"; let identity=repository_identity_for_workspace(workspace)?;
 let ledger=ReleaseLedger::open(root.clone(),&identity)?;
 if mode=="admit" {
  let outcome=admit_natural_release_with_launcher(workspace,"Release the completed RRC parity repair as version 0.24.5.",&root,|workspace,repository,repo_identity| {
   assert_eq!(repository,repo);assert_eq!(repo_identity,identity);
   println!("Native canonical release workspace: {}",workspace.display());
   Ok(())
  })?;
  match outcome { NaturalReleaseAdmission::Started(message)=>println!("{message}"), _=>panic!("native canonical admission requires unresolved clarification: {outcome:?}") };
  return Ok(());
 }
 let key=sha2::Sha256::digest(identity.as_bytes());
 let key=key.iter().map(|byte|format!("{byte:02x}")).collect::<String>();
 let owner=std::fs::OpenOptions::new().create(true).truncate(false).read(true).write(true).open(root.join(format!("{key}.owner")))?;
 fs2::FileExt::try_lock_exclusive(&owner)?;
 let cancelled=Arc::new(AtomicBool::new(false));
 let _watcher=CancellationWatcher::start(ledger.clone(),Arc::clone(&cancelled));
 let governor=HostResourceGovernor::new(ResourcePolicy::default(),root.join("host-resources/scheduler"),"/home/Alex/Projects/agent-vesper/target/production-release")?;
 if mode=="gates" {
  let executor=NativeReleaseExecutor::new(workspace,Arc::clone(&cancelled))?.with_resource_governor(governor);
  for gate in production_local_gates() {
   println!("BEGIN native governed gate {}: {}",gate.name,gate.command);
   match executor.run_local_gate(&gate) {Ok(receipt)=>println!("PASS native governed gate {}\n{}",gate.name,receipt),Err(error)=>{println!("FAIL native governed gate {}: {}",gate.name,error);return Err(error.into());}}
  }
  return Ok(());
 }
 let selected=ledger.load()?.and_then(|record|record.mutation.release_workspace).map(PathBuf::from);
 let workspace=selected.as_deref().unwrap_or(workspace);
 let executor=NativeReleaseExecutor::new(workspace,Arc::clone(&cancelled))?.with_resource_governor(governor);
 let github=GhCliEvidenceAdapter.with_cancellation(Arc::clone(&cancelled));
 let health=CurlGitHubStatusAdapter.with_cancellation(Arc::clone(&cancelled));
 let head=std::process::Command::new("git").args(["rev-parse","HEAD"]).current_dir(workspace).output()?;
 assert!(head.status.success());if matches!(mode.as_str(),"verify"|"push"|"tag") {assert_eq!(String::from_utf8(head.stdout)?.trim(),sha);}
 let mut record=if mode=="init" {
  assert!(ledger.load()?.is_none(),"cannot replace an existing production release epoch");
  let row=start_release(&identity,"0.24.5","main",sha)?;
  ledger.save(&row)?;row
 } else {ledger.load()?.expect("initialized native production release epoch")};
 if matches!(mode.as_str(),"verify"|"push"|"tag") {assert_eq!(record.active_commit(),Some(sha.as_str()));}
 if mode=="closeout" {
  assert_eq!(record.state,ReleaseRecoveryState::Published);
  apply_controller_event(&mut record,ReleaseControllerEvent::PostReleaseCloseoutStarted(vec!["release:explicit-authorized-native-closeout".into()]))?;
  ledger.save(&record)?;
 }
 if mode=="verify" {
  assert_eq!(record.state,ReleaseRecoveryState::LocalVerification);
  assert!(record.mutation.in_flight_operation.is_none(),"uncertain mutation cannot replay");
  while record.state==ReleaseRecoveryState::LocalVerification {
   println!("Native local progression: {}", record.render_status());
   advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&github,health:&health,repair_factory:None,cancelled:Arc::clone(&cancelled)})?;
  }
  assert_eq!(record.state,ReleaseRecoveryState::CandidateReady);
  assert_eq!(record.mutation.local_gates.iter().filter(|gate|gate.state==vesper_harness::release_recovery::SettlementState::Succeeded).count(),production_local_gates().len()+1);
 } else if mode=="infra-retry" {
  assert!(record.retry_admission(vesper_harness::release_recovery::RetryKind::Infrastructure).admitted,"native infrastructure admission is required");
  assert!(record.mutation.in_flight_operation.is_none(),"uncertain mutation cannot replay");
  record.mutation.in_flight_operation=Some("infrastructure retry: explicit user release authorization; native service-recovery admission".into());ledger.save(&record)?;
  advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&github,health:&health,repair_factory:None,cancelled:Arc::clone(&cancelled)})?;
  record.mutation.in_flight_operation=None;ledger.save(&record)?;
 } else if mode=="push" || mode=="tag" {
  assert!(record.mutation.in_flight_operation.is_none(),"uncertain mutation cannot replay");
  if mode=="push" {assert_eq!(record.state,ReleaseRecoveryState::CandidateReady);} else {
   assert_eq!(github.current_main_commit(repo)?.as_deref(),Some(sha.as_str()));
   refresh_remote_evidence(&mut record,repo,&github)?;
   assert_eq!(record.state,ReleaseRecoveryState::RemoteGatesGreen);
  }
  record.mutation.in_flight_operation=Some(format!("{mode}: explicit user release authorization"));ledger.save(&record)?;
  advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&github,health:&health,repair_factory:None,cancelled:Arc::clone(&cancelled)})?;
  record.mutation.in_flight_operation=None;ledger.save(&record)?;
 } else if mode=="watch" {
  let mut unchanged_polls=0u8;
  loop {
   if matches!(record.state,ReleaseRecoveryState::RemoteGatesGreen|ReleaseRecoveryState::Published|ReleaseRecoveryState::Complete) {break;}
   if record.state==ReleaseRecoveryState::ClassifyingFailure {
    assert!(!record.retry_admission(vesper_harness::release_recovery::RetryKind::Infrastructure).admitted,"infrastructure retry requires explicit journaled infra-retry mode");
    assert_eq!(vesper_harness::release_recovery::next_directive(&record,unchanged_polls),vesper_harness::release_recovery::ReleaseDirective::RunExternalHealthCheck,"read-only watch cannot perform source repair");
   }
   assert!(matches!(record.state,ReleaseRecoveryState::RemoteGateRunning|ReleaseRecoveryState::WaitingForMatrix|ReleaseRecoveryState::Publishing|ReleaseRecoveryState::PostReleaseCloseout|ReleaseRecoveryState::ClassifyingFailure|ReleaseRecoveryState::ExternalHealthCheck|ReleaseRecoveryState::PausedExternal),"read-only watch cannot perform repair or implicit publication: {:?}",record.state);
   let previous_gates=record.required_gates.clone();let previous_state=record.state;
   let before=std::time::Instant::now();
   advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&github,health:&health,repair_factory:None,cancelled:Arc::clone(&cancelled)})?;
   if matches!(record.state,ReleaseRecoveryState::RemoteGatesGreen|ReleaseRecoveryState::Published|ReleaseRecoveryState::Complete) {break;}
   println!("{}",record.render_status());
   unchanged_polls=if previous_gates==record.required_gates && previous_state==record.state {unchanged_polls.saturating_add(1)} else {0};
   let delay=if record.state==ReleaseRecoveryState::PausedExternal {30} else {vesper_harness::release_recovery::poll_interval(unchanged_polls).as_secs()};
   for _ in 0..delay*10 {if cancelled.load(std::sync::atomic::Ordering::Acquire) {return Err("native cancellation requested".into());}std::thread::sleep(std::time::Duration::from_millis(100));}
   record.metrics.ci_wait_millis=record.metrics.ci_wait_millis.saturating_add(before.elapsed().as_millis().min(u64::MAX as u128) as u64);ledger.save(&record)?;
  }
 } else if mode=="poll" || mode=="closeout" {
  assert_ne!(record.state,ReleaseRecoveryState::RemoteGatesGreen,"tag requires explicit journaled tag mode");
  advance_release(&mut record,ReleaseAdvanceContext{workspace,repository:repo,ledger:&ledger,executor:&executor,github:&github,health:&health,repair_factory:None,cancelled})?;
 } else {assert_eq!(mode,"init");}
 println!("Production native controller: source={sha}; mode={mode}; state={:?}; tag={:?}; tag_object={:?}; publication_run={:?}; verified_assets={}",record.state,record.mutation.tag_name,record.mutation.tag_object,record.mutation.publication_run_id,record.mutation.published_asset_names.len());
 println!("{}",record.render_status());
 Ok(())
}
use sha2::Digest;

struct CancellationWatcher {done:Arc<AtomicBool>,thread:Option<std::thread::JoinHandle<()>>}
impl CancellationWatcher {fn start(ledger:ReleaseLedger,cancelled:Arc<AtomicBool>)->Self {let done=Arc::new(AtomicBool::new(false));let d=Arc::clone(&done);let thread=std::thread::spawn(move || {while !d.load(std::sync::atomic::Ordering::Acquire) {if ledger.load().ok().flatten().is_some_and(|r|r.state==ReleaseRecoveryState::Cancelled) {cancelled.store(true,std::sync::atomic::Ordering::Release);break;}std::thread::sleep(std::time::Duration::from_millis(100));}});Self{done,thread:Some(thread)}}}
impl Drop for CancellationWatcher {fn drop(&mut self){self.done.store(true,std::sync::atomic::Ordering::Release);if let Some(t)=self.thread.take(){let _=t.join();}}}
