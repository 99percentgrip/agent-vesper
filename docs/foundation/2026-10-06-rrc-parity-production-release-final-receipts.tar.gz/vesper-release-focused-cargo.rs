use vesper_harness::host_resources::{HostResourceGovernor,ResourcePolicy,GateCost};
fn main()->Result<(),Box<dyn std::error::Error>> {
 let governor=HostResourceGovernor::new(ResourcePolicy::default(),"/home/Alex/.local/state/agent-vesper/release-recovery/host-resources/scheduler","/home/Alex/Projects/agent-vesper/target/production-release")?;
 let admission=loop { match governor.preflight(GateCost::Expensive) { Ok(admission)=>break admission, Err(error)=>{ eprintln!("RESOURCE DEFER: {error}"); std::thread::sleep(std::time::Duration::from_secs(15)); } } };
 let mut cmd=std::process::Command::new("cargo");
 cmd.args(std::env::args().skip(1)).current_dir("/tmp/vesper-production-release");
 for (key,value) in admission.cargo.environment(){cmd.env(key,value);}
 
 let status=cmd.status()?;assert!(status.success(),"actual governed library build failed");println!("Native default resource admission and bounded Cargo environment: repair producer libraries built");Ok(())
}
