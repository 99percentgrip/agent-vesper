import pathlib,subprocess,json,hashlib,tarfile,zipfile
repo='99percentgrip/agent-vesper'; sha='7e837db36f4090e566ac1a7461b5b103b8649368'; tag='v0.24.5'; root=pathlib.Path('/tmp/vesper-release-v0.24.5-published-assets');root.mkdir(exist_ok=True)
def api(path):return json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/{path}']))
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
release=api('releases/tags/'+tag);assert not release['draft'] and not release['prerelease'] and release['tag_name']==tag
ref=api('git/ref/tags/'+tag);assert ref['object']['type']=='tag'; annotated=api('git/tags/'+ref['object']['sha']);assert annotated['object']['sha']==sha and annotated['object']['type']=='commit'
assets={a['name']:a for a in release['assets']};assert len(assets)==len(release['assets']); archives=[f'agent-vesper-acp-{p}.{ext}' for p,ext in [('linux-x86_64','tar.gz'),('linux-aarch64','tar.gz'),('darwin-x86_64','tar.gz'),('darwin-aarch64','tar.gz'),('windows-x86_64','zip')]]+[f'vesper-web-driver-{p}.tar.gz' for p in ['linux-x86_64','linux-aarch64']]
required=set(archives+[name+'.sha256' for name in archives]);assert required<=assets.keys()
verified=[]
for name,asset in assets.items():
 assert pathlib.Path(name).name==name and asset['state']=='uploaded' and asset['size']>0
 path=root/name
 if not path.exists():subprocess.run(['gh','release','download',tag,'--repo',repo,'--pattern',name,'--dir',str(root)],check=True)
 actual=digest(path);assert path.stat().st_size==asset['size'] and asset['digest']=='sha256:'+actual
 verified.append({'name':name,'id':asset['id'],'bytes':asset['size'],'sha256':actual});print('Verified actual published bytes:',name,flush=True)
for name in archives:
 words=(root/(name+'.sha256')).read_text(encoding='utf-8-sig').split();assert len(words)==2 and words[0].lower()==digest(root/name) and words[1].lstrip('*')==name
payload=[]
for name in archives[:5]:
 path=root/name
 platform=name.removeprefix('agent-vesper-acp-').removesuffix('.tar.gz').removesuffix('.zip')
 driver_platform='linux-aarch64' if platform.endswith('aarch64') else 'linux-x86_64'
 driver=f'vesper-web-driver-{driver_platform}.tar.gz'
 def check_driver(open_entry):
  h=hashlib.sha256()
  with open_entry('agent-vesper-acp/web-driver/image.tar.gz') as stream:
   for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
  assert h.hexdigest()==digest(root/driver)
  with open_entry('agent-vesper-acp/web-driver/image.sha256') as stream:words=stream.read().decode('utf-8-sig').split()
  assert words[0].lower()==h.hexdigest() and words[1].lstrip('*')==driver
  with open_entry('agent-vesper-acp/web-driver/image-id') as stream:assert stream.read()==(root/f'vesper-web-driver-{driver_platform}.image-id').read_bytes()
 if name.endswith('.zip'):
  with zipfile.ZipFile(path) as archive:
   names=set(archive.namelist());assert {'agent-vesper-acp/agent-vesper-acp.exe','agent-vesper-acp/agent-vesper-tui.exe','agent-vesper-acp/vesper-web-fetch.exe','agent-vesper-acp/sandbox_init.exe'}<=names;assert any(n.startswith('agent-vesper-acp/skills/') for n in names)
   check_driver(archive.open)
 else:
  with tarfile.open(path) as archive:
   names=set(archive.getnames());assert {'agent-vesper-acp/agent-vesper-acp','agent-vesper-acp/agent-vesper-tui','agent-vesper-acp/vesper-web-fetch','agent-vesper-acp/sandbox_init'}<=names;assert any(n.startswith('agent-vesper-acp/skills/') for n in names)
   check_driver(archive.extractfile)
 payload.append({'archive':name,'both_native_hosts_and_tools':True,'seed_skills':True,'bundled_tested_driver_platform':driver_platform,'bundled_driver_bytes_checksum_and_identity':True})
receipt={'candidate_sha':sha,'version':'0.24.5','tag':tag,'annotated_tag_object':ref['object']['sha'],'release_id':release['id'],'release_url':release['html_url'],'published_at':release['published_at'],'assets':verified,'payload_checks':payload,'passed':True,'scope':'Actual downloaded public assets, server digest and seven checksum pairs; payload listing and all five bundled driver byte/checksum/identity equivalence. No installer or binary executed.'}
pathlib.Path('/tmp/vesper-release-published-assets-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');pathlib.Path('/tmp/vesper-release-published-release.json').write_text(json.dumps(release,indent=2)+'\n');pathlib.Path('/tmp/vesper-release-published-tag.json').write_text(json.dumps({'ref':ref,'annotated':annotated},indent=2)+'\n');print('All actual archive, checksum and bundled-payload checks passed.',flush=True)
