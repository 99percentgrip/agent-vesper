sh -n scripts/install.sh scripts/uninstall.sh
test -f docs/architecture.md
test -f docs/workspace-map.md
test -f docs/dependencies.md
test -f docs/migration-status.md
test -f docs/stage2/contract-completion-report.md
test -f docs/stage2/stage3-readiness.md
test -f docs/stage3/glm-adapter-report.md
test -f docs/stage3/stage4-readiness.md
test -f docs/stage4/acp-adapter-report.md
test -f docs/stage4/stage5-readiness.md
test -f docs/stage5/session-store-report.md
test -f docs/stage5/stage6-readiness.md
test "$(find docs/adr -maxdepth 1 -name '*.md' | wc -l)" -ge 8
